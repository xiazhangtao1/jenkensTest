﻿#include <iostream>
#include <memory>
#include <string>
#include <stdlib.h>
#include <functional>
#include <string.h>   /* for strcpy */ 
#include <algorithm>  /* 为了使用 std::copy */ 
#include <json-c/json.h>
#include <cstring>
#include <thread>
#include <chrono>

#include <pplx/pplx.h>

#include <etcd/SyncClient.hpp>    /* #include "etcd/SyncClient.hpp" */
#include <etcd/Watcher.hpp>       /* #include "etcd/Watcher.hpp" */
#include <etcd/Client.hpp>        /* #include "etcd/Client.hpp" */
#include <etcd/KeepAlive.hpp>
#include <etcd/v3/Member.hpp>

#include "usp_config.hpp"

/******************定义全局变量*************************/
//static const std::string etcd_url = etcdv3::detail::resolve_etcd_endpoints("http://192.168.2.75:2389");
static const std::string etcd_url = "http://192.168.2.75:2389";

/*******************************************************/

unsigned int UspCfg_Read_KeyNum(char* pKey, unsigned long *pulNum, void **pOutput)
{
    unsigned int ulRet = 0;
    etcd::Client etcd(etcd_url);

    /* 读取键值函数调用 */
    etcd::Response resp = etcd.ls("/").get();
    
    etcd::Response *ptr = new etcd::Response(resp);
    int length;
    
    if (resp.error_code())
    {
        std::cout << "--------------error----------------" << std::endl;
        ulRet = 1;
        pOutput = NULL;
    }
    else
    {
        *pulNum = resp.keys().size();
        *pOutput = ptr;
        
        std::string str_value   = resp.value(1).as_string();
        
        length = str_value.length();
        std::cout << "length = " << length << std::endl;

        // 验证pOutput是否被正确赋值
        if (pOutput == NULL)
        {
            std::cout << "UspCfgRead: pOutput赋值失败，可能导致后续问题" << std::endl;
            // 可以根据具体需求在这里进行更合适的错误处理，比如抛出异常或者返回特定错误码
            ulRet = 1;
        }
    }
    //etcd.close();
    return ulRet;
}

unsigned int UspCfg_Read_KeyValue(void *voidPtr, unsigned long ulOffset, char **pKey, char **pValue)
{
    unsigned int ulRet = 0;
    std::string str_key;
    std::string str_value;
    etcd::Response *wrapper=(etcd::Response *)voidPtr;
    std::string test = "123";
    char char1[9];
    
    if (wrapper->error_code())
    {
        std::cout << "118" << std::endl;
        ulRet = 1;
    }
    else
    {
        if (wrapper->keys().size() > 0)
        {
            str_key   = wrapper->value(ulOffset).key();
            str_value = wrapper->value(ulOffset).as_string();

            *pKey = new char[str_key.length() + 1];
            if (*pKey == NULL)
            {
                // 内存申请失败处理
                std::cerr << "为pKey分配内存失败！" << std::endl;
                return 1;
            }
            
            *pValue = new char[str_value.length() + 1];
            if (*pValue == NULL) 
            {
                std::cerr << "为pValue分配内存失败！" << std::endl;
                // 如果pKey已经分配成功，需要先释放pKey的内存，避免内存泄漏
                if (*pKey!= NULL) {
                    delete[] *pKey;
                    *pKey = NULL;
                }
                // 同样可以根据具体需求进行进一步处理，比如返回错误码、退出程序等
                return 1;
            }

            strcpy(*pKey, str_key.c_str());
            strcpy(*pValue, str_value.c_str());
            //std::cout << "pKey = " << *pKey << ", pValue = " << *pValue << std::endl;
        }
        else
        {
            ulRet = 1;
        }
    }

    return ulRet;
}

// 释放resp内存的函数
void UspCfg_BufFree_Resp(void *p)
{
    etcd::Response *q = (etcd::Response *)p;
    // 先判断指针是否有效，避免后续对空指针进行操作
    if (!p)
    {
        std::cerr << "传入的指针p为空，无需进行内存释放操作" << std::endl;
        return;
    }
    
    if (q!= NULL)
    {
        delete q;
    }
    else
    {
        return;
    }
}

// 释放key/value内存的函数
void UspCfg_BufFree_KeyValue(char *pKeyOrValue) 
{
    if (pKeyOrValue!= NULL) 
    {
        delete[] pKeyOrValue;
        pKeyOrValue = NULL;
    }
}
void FunctionCallForRead()
{
    const int numIterations = 5;  // 设置循环调用的次数
    void *pOutputInfo;
    unsigned long ulNum = 0;
    char szPath[256];
    unsigned int ulRet;
    unsigned int ulRet1;
    char *pRead_Key = NULL;
    char *pRead_Value = NULL;
    
    strcpy(szPath, "/");
    
    ulRet = UspCfg_Read_KeyNum(szPath, &ulNum, &pOutputInfo);
    
    if ((0 == ulRet) && (pOutputInfo))
    {
        for (int i = 0; i < ulNum; ++i)
        {
            
            ulRet1 = UspCfg_Read_KeyValue(pOutputInfo, i, &pRead_Key, &pRead_Value);
            if (ulRet1 == 1)
            {
                std::cout << "在读取键值对时出现错误，索引为：" << i << std::endl;
                // 可以根据具体需求决定是否继续循环或者采取其他措施
            }
            else
            {
                if ((pRead_Key != NULL) && (pRead_Value != NULL))
                {
                    std::cout << "pRead_Key = " << pRead_Key << ", pRead_Value = " << pRead_Value << std::endl;

                }
                else
                {
                    std::cout << "NULL " << std::endl;
                }
            }
            
        }

        // 释放内存
        UspCfg_BufFree_Resp(pOutputInfo);
        UspCfg_BufFree_KeyValue(pRead_Key);
        UspCfg_BufFree_KeyValue(pRead_Value);
    }
    else
    {
        // 当UspCfgRead函数返回错误时，释放可能已经分配的pOutputInfo相关内存
        if (pOutputInfo!= NULL)
        {
            UspCfg_BufFree_Resp(pOutputInfo);
        }
    }

}

/******************************************************************
函数名称: ETCDAPI_DeleteKey
功能描述: 删除键 接口函数
输入参数: char* pKey
输出参数: 无
返回数值: 0: success 1:fail
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
int UspCfg_Delete_Key(char* pKey, bool recursive)
{
    /* etcd::Client etcd("http://192.168.2.75:2389"); */
    etcd::Client etcd(etcd_url);
    etcd.set("/test/delete", "foo");

    std::string key_Delete(pKey); /* 一键多值,如何删除该键的某个值 ps:这种情况是不是可以理解为修改键 */
    etcd::SyncClient client(etcd_url);
    
    etcd::Response resp = etcd.rmdir(key_Delete, true).get();
    
    if (resp.error_code())
    {
        std::cout << "delet " << resp.watch_id() << " fails with "
                  << resp.error_code() << ": " << resp.error_message() << std::endl;
        return 1;
    }
    else
    {
        for (int i = 0; i < resp.keys().size(); ++i)
        {
            std::cout << "Delete key: " << resp.value(i).key() << ", value = " << resp.value(i).as_string() << std::endl;
        }
        return 0;
    }
}

void FunctionCallForDelete()
{
    unsigned int ulRet = 0;
    char szPath[256];
    bool recursive;
    
    strcpy(szPath, "/test/key");
    recursive = false; /* true:递归删除 false:非递归删除 */
    
    ulRet = UspCfg_Delete_Key(szPath, recursive);
    if (ulRet == 0)
    {
        std::cout << "delet succsess" << std::endl;
    }
}


/******************************************************************
函数名称: ETCDAPI_DeleteKey1
功能描述: 删除键 接口函数
输入参数: char* pKey
输出参数: 无
返回数值: 0: success 1:fail
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
int UspCfg_Delete_Key1(char* pKeyStart, char* pKeyEnd)
{
    /* etcd::Client etcd("http://192.168.2.75:2389"); */
    etcd::Client etcd(etcd_url);
    etcd.set("/test/delete", "foo");

    std::string start_dir(pKeyStart);
    std::string end_dir(pKeyEnd);
    
    etcd::Response resp = etcd.rmdir(start_dir, end_dir).get();
    //etcd::Response resp = etcd.rm(start_dir).get();/* 删除单个指定的键值对 */
    if (resp.error_code())
    {
        std::cout << "delet " << resp.watch_id() << " fails with "
                  << resp.error_code() << ": " << resp.error_message() << std::endl;
        return 1;
    }
    else
    {
        for (int i = 0; i < resp.keys().size(); ++i)
        {
            std::cout << "Delete key: " << resp.value(i).key() << ", value = " << resp.value(i).as_string() << std::endl;
        }
        return 0;
    }
}


void FunctionCallForDelete1()
{
    unsigned int ulRet = 0;
    char szPathStart[256];
    char szPathEnd[256];
    
    strcpy(szPathStart, "/test/key3");
    strcpy(szPathEnd, "/test/key3");
    
    ulRet = UspCfg_Delete_Key1(szPathStart, szPathEnd);
    if (ulRet == 0)
    {
        std::cout << "delet succsess" << std::endl;
    }
}



std::string etcd_endpoint = "http://192.168.10.35:2489";
etcd::Client etcd_client(etcd_endpoint);

/*
etcd_client.get(key_to_get)：获取单个指定的键值对
*/
void FunctionCallForGet()
{
    std::string key_to_get = "/test/key4";

    int64_t target_revision = 2362; // 假设要获取版本为5的键值对
    // 调用get函数获取键值对，返回一个异步任务
    pplx::task<etcd::Response> get_task = etcd_client.get(key_to_get);
    
    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = get_task.get();
        if (response.is_ok()) {
            // 如果操作成功，获取并打印键值对中的值
            
            std::string key = response.value().key();
            std::string value = response.value().as_string();
            std::cout << "获取键值对成功，键为"<< key << ", 值为: " << value << std::endl;
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "获取键值对失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取键值对时发生异常: " << e.what() << std::endl;
    }
}

/*
target_revision指的是更新修订号
etcd_client.get(key_to_get, target_revision)：该函数运行时提示：获取键值对失败，错误码: 100, 错误信息: etcd-cpp-apiv3: key not found
*/
void FunctionCallForGet_Revision()
{
    std::string key_to_get = "/test/key4";

    int64_t target_revision = 2362; // 假设要获取版本为5的键值对
    
    // 调用get函数获取指定版本的键值对，返回一个异步任务
    pplx::task<etcd::Response> get_task = etcd_client.get(key_to_get, target_revision);
    
    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = get_task.get();
        if (response.is_ok()) {
            // 如果操作成功，获取并打印键值对中的值
            
            std::string key = response.value().key();
            std::string value = response.value().as_string();
            std::cout << "获取键值对成功，键为"<< key << ", 值为: " << value << std::endl;
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "获取键值对失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取键值对时发生异常: " << e.what() << std::endl;
    }
}

/* 写入或更新一个键值对，lease_id租约ID控制键值对的生存时间 下面代码实现不能自动获取租约ID */
void FunctionCallForSet()
{
    std::string key_to_set = "/test_key";
    std::string value_to_set = "test_value 修改";

    int64_t ttlSeconds = 3600; // 设置租约的生存时间为300秒，可根据实际需求修改
    pplx::task<etcd::Response> leasegrantTask = etcd_client.leasegrant(ttlSeconds);
    
    
    try
    {
        etcd::Response leaseGrantResponse = leasegrantTask.get();
        if (leaseGrantResponse.is_ok()) 
        {
            const std::vector<int64_t>& leasesVec = leaseGrantResponse.leases();

            std::cout << "---Lease ID: " << leasesVec.size() << std::endl;
            for (int64_t lease_id : leasesVec)
            {
                std::cout << "Lease ID: " << lease_id << std::endl;
            }
            int64_t lease_id = 7587882418572849223; // 假设这里给定一个租约ID，实际应用中可根据需求生成或获取合适的租约ID
            std::cout << "成功获取租约ID: " << lease_id << std::endl;

            #if 1
            // 调用set函数设置键值对，返回一个异步任务
            pplx::task<etcd::Response> set_task = etcd_client.set(key_to_set, value_to_set, lease_id);

            // 获取异步任务的结果，即etcd::Response对象
            etcd::Response response = set_task.get();
            try
            {
                if (response.is_ok()) {
                    // 如果操作成功，打印相关信息
                    std::cout << "键值对设置成功！" << std::endl;
                    std::cout << "设置后的键值对：键 = " << key_to_set << ", 值 = " << value_to_set << std::endl;
                    std::cout << "修订版本号：" << response.index() << ", CMD: " << response.action() << std::endl;
                } 
                else 
                {
                    // 如果操作失败，打印错误码和错误信息
                    std::cout << "键值对设置失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
                }
            }
            catch (const std::exception& e)
            {
                // 捕获获取异步任务结果过程中可能出现的异常并打印
                std::cout << "设置键值对时发生异常: " << e.what() << std::endl;
            }
            #endif
        } 
        else 
        {
            std::cout << "租约创建失败，错误码: " << leaseGrantResponse.error_code() << "，错误信息: " << leaseGrantResponse.error_message() << std::endl;
        }
    }
    catch (const std::exception& e) 
    {
        std::cout << "获取租约ID时发生异常: " << e.what() << std::endl;
    }
}

/*
添加一个新的键值对
键值存在时提示：键值对添加失败，错误码: 105, 错误信息: etcd-cpp-apiv3: key already exists
*/
void FunctionCallForAdd()
{
    std::string key_to_add = "/new_key";
    std::string value_to_add = "new_value";
    int64_t lease_id = 7587882418572849277; // 假设这里给定一个租约ID，实际应用中可根据需求生成或获取合适的租约ID

    // 调用add函数添加键值对，返回一个异步任务
    pplx::task<etcd::Response> add_task = etcd_client.add(key_to_add, value_to_add, lease_id);
    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = add_task.get();
        if (response.is_ok()) {
            // 如果操作成功，打印相关信息
            std::cout << "键值对添加成功！" << std::endl;
            std::cout << "添加后的键值对：键 = " << key_to_add << ", 值 = " << value_to_add << std::endl;
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "键值对添加失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "添加键值对时发生异常: " << e.what() << std::endl;
    }
}

/*
修改已存在的键值对
键值对不存在则提示：键值对修改失败，错误码: 100, 错误信息: etcd-cpp-apiv3: key not found
*/
void FunctionCallForModify()
{
    std::string keyToModify = "/test/key";
    std::string newValue = "modified_value";
    int64_t leaseId = 7587882418572849277;  // 假设一个租约ID，实际应用中可根据需求生成或获取合适的租约ID

    // 调用modify函数修改键值对，返回一个异步任务
    pplx::task<etcd::Response> modifyTask = etcd_client.modify(keyToModify, newValue, leaseId);
    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = modifyTask.get();
        if (response.is_ok()) {
            std::cout << "键值对修改成功。" << std::endl;
            std::cout << "修改后的键值对：键 = " << keyToModify << ", 值 = " << newValue << std::endl;
        } else {
            std::cout << "键值对修改失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "获取异步任务结果时出现异常: " << e.what() << std::endl;
    }
}

/*
当键"/test_key_if"的值等于"original_value"时，则被修改为新值"modified_value_if";
当键"/test_key_if"的值等于"original_value"时，提示：旧值与条件不匹配，键值对未修改。
当键"/test_key_if"不存在时，提示：旧值与条件不匹配，键值对未修改。
*/
void FunctionCallForModifyIf_Value()
{
    std::string keyToModifyIf = "/test_key_if";
    std::string newValueIf = "modified_value_if";
    std::string oldValueIf = "original_value";
    int64_t leaseIdIf = 7587882418572849277;  // 假设一个租约ID，实际应用中可根据需求生成或获取合适的租约ID

    // 调用modify_if函数（基于旧值判断）修改键值对，返回一个异步任务
    pplx::task<etcd::Response> modifyIfTask = etcd_client.modify_if(keyToModifyIf, newValueIf, oldValueIf, leaseIdIf);
    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = modifyIfTask.get();
        if (response.is_ok()) {
            std::cout << "基于旧值条件判断后，键值对修改成功。" << std::endl;
            std::cout << "修改后的键值对：键 = " << keyToModifyIf << ", 值 = " << newValueIf << std::endl;
        } else if (response.error_code() == etcdv3::ERROR_COMPARE_FAILED) {
            std::cout << "旧值与条件不匹配，键值对未修改。" << std::endl;
        } else {
            std::cout << "键值对修改失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "获取异步任务结果时出现异常: " << e.what() << std::endl;
    }
}

/* 
该函数需要清楚索引代表的含义，对应的是键值对的更新修订号
更新修订号与oldIndexIfIndex不等时提示：旧索引与条件不匹配，键值对未修改。
*/
void FunctionCallForModifyIf_Index()
{
    std::string keyToModifyIfIndex = "/test_key_if_index";
    std::string newValueIfIndex = "modified_value_if_index";
    int64_t oldIndexIfIndex = 2399;  // 假设一个旧索引值，实际应用中根据需求设定
    int64_t leaseIdIfIndex = 7587882418572849277;  // 假设一个租约ID，实际应用中可根据需求生成或获取合适的租约ID

    // 调用modify_if函数（基于旧索引判断）修改键值对，返回一个异步任务
    pplx::task<etcd::Response> modifyIfIndexTask = etcd_client.modify_if(keyToModifyIfIndex, newValueIfIndex, oldIndexIfIndex, leaseIdIfIndex);
    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = modifyIfIndexTask.get();
        if (response.is_ok()) {
            std::cout << "基于旧索引条件判断后，键值对修改成功。" << std::endl;
            std::cout << "修改后的键值对：键 = " << keyToModifyIfIndex << ", 值 = " << newValueIfIndex << std::endl;
        } else if (response.error_code() == etcdv3::ERROR_COMPARE_FAILED) {
            std::cout << "旧索引与条件不匹配，键值对未修改。" << std::endl;
        } else {
            std::cout << "键值对修改失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "获取异步任务结果时出现异常: " << e.what() << std::endl;
    }
}

void FunctionCallForLs()
{
    std::string keyPrefix = "/test";
    
    // 调用ls函数列出以指定key为起始的键值对相关信息，返回一个异步任务
    pplx::task<etcd::Response> lsTask = etcd_client.ls(keyPrefix);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lsTask.get();

        if (response.is_ok()) {
            // 如果操作成功，获取并输出键列表和值列表（假设返回内容包含这些信息）
            const std::vector<std::string>& keys = response.keys();
            const std::vector<etcd::Value>& values = response.values();
        
            std::cout << "index = " << response.index() << std::endl;

            std::cout << "列出以 " << keyPrefix << " 为起始的键值对信息：" << std::endl;
            for (size_t i = 0; i < keys.size(); ++i) {
                std::cout << "键: " << keys[i] << ", 值: " << response.value(i).as_string()  << ", 值: " << values[i] << std::endl;
            }
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "列出键值对信息失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取列出信息时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForLs_Limit()
{

    std::string keyPrefix = "/test/";
    size_t resultLimit = 2; // 设定只获取5个结果

    // 调用ls函数列出以指定key为起始的部分键值对相关信息，返回一个异步任务
    pplx::task<etcd::Response> lsTask = etcd_client.ls(keyPrefix, resultLimit);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lsTask.get();

        if (response.is_ok()) {
            // 如果操作成功，获取并输出键列表和值列表（假设返回内容包含这些信息）
            const std::vector<std::string>& keys = response.keys();
            const std::vector<etcd::Value>& values = response.values();

            std::cout << "列出以 " << keyPrefix << " 为起始的部分键值对信息（最多 " << resultLimit << " 个）：" << std::endl;
            for (size_t i = 0; i < keys.size(); ++i) {
                std::cout << "键: " << keys[i] << ", 值: " << values[i] << std::endl;
            }
        } else {
        // 如果操作失败，打印错误码和错误信息
            std::cout << "列出键值对信息失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取列出信息时发生异常: " << e.what() << std::endl;
    }
}

/* etcd_client.ls(keyPrefix, resultLimit, targetRevision)对第三个参数没理解 */
void FunctionCallForLs_Limit_Revision()
{
    std::string keyPrefix = "/test/";
    size_t resultLimit = 100;     // 设定只获取resultLimit个结果
    int64_t targetRevision = 2040;  // 查询最新版本

    // 调用ls函数列出以指定key为起始的部分键值对相关信息（指定版本），返回一个异步任务
    pplx::task<etcd::Response> lsTask = etcd_client.ls(keyPrefix, resultLimit, targetRevision);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lsTask.get();

        if (response.is_ok()) {
            // 如果操作成功，获取并输出键列表和值列表（假设返回内容包含这些信息）
            const std::vector<std::string>& keys = response.keys();
            const std::vector<etcd::Value>& values = response.values();

            std::cout << "列出以 " << keyPrefix << " 为起始的部分键值对信息（最多 " 
                      << resultLimit << " 个，版本为 " << targetRevision << "）,满足要求的键值对有：" << keys.size() << " 个" << std::endl;
            for (size_t i = 0; i < keys.size(); ++i) {
                std::cout << "键: " << keys[i] << ", 值: " << values[i] << std::endl;
            }
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "列出键值对信息失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的精彩并打印
        std::cout << "获取列出信息时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForLs_Rangend()
{
    std::string keyStart = "/test/";
    std::string rangeEnd = "/test/key/4";

    // 调用ls函数列出从指定key开始到range_end（不包括range_end本身）之间的键值对相关信息，返回一个异步任务
    pplx::task<etcd::Response> lsTask = etcd_client.ls(keyStart, rangeEnd);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lsTask.get();

        if (response.is_ok()) {
            // 如果操作成功，获取并输出键列表和值列表（假设返回内容包含这些信息）
            const std::vector<std::string>& keys = response.keys();
            const std::vector<etcd::Value>& values = response.values();

            std::cout << "列出从 " << keyStart << " 到 " << rangeEnd << "（不包括 " << rangeEnd 
                      << "）之间的键值对信息, 满足条件的键值对有: " << keys.size() << " 个" << std::endl;
            for (size_t i = 0; i < keys.size(); ++i) {
                std::cout << "键: " << keys[i] << ", 值: " << values[i] << std::endl;
            }
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "列出键值对信息失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取列出信息时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForLs_Rangend_Limit()
{
    std::string keyStart = "/test/key";
    std::string rangeEnd = "/test/key/4";
    size_t resultLimit = 3; // 设定只获取3个结果

    // 调用ls函数列出从指定key开始到range_end（不包括range_end本身）之间的部分键值对相关信息，返回一个异步任务
    pplx::task<etcd::Response> lsTask = etcd_client.ls(keyStart, rangeEnd, resultLimit);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lsTask.get();

        if (response.is_ok()) {
            // 如果操作成功，获取并输出键列表和值列表（假设返回内容包含这些信息）
            const std::vector<std::string>& keys = response.keys();
            const std::vector<etcd::Value>& values = response.values();

            std::cout << "列出从 " << keyStart << " 到 " << rangeEnd << "（不包括 " << rangeEnd << "）之间的部分键值对信息（最多 " << resultLimit << " 个）：" << std::endl;
            for (size_t i = 0; i < keys.size(); ++i) {
                std::cout << "键: " << keys[i] << ", 值: " << values[i] << std::endl;
            }
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "列出键值对信息失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取列出信息时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForLs_Rangend_Limit_Reversion()
{
    // 设置查询参数
    std::string keyPrefix = "/test/";
    std::string rangeEnd = "/test/key/4";
    size_t resultLimit = 4;
    int64_t targetRevision = 0;

    // 调用ls函数进行查询，返回一个异步任务
    pplx::task<etcd::Response> lsTask = etcd_client.ls(keyPrefix, rangeEnd, resultLimit, targetRevision);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lsTask.get();

        if (response.is_ok()) {
            // 如果操作成功，获取并输出键列表和值列表（假设返回内容包含这些信息）
            const std::vector<std::string>& keys = response.keys();
            const std::vector<etcd::Value>& values = response.values();

            std::cout << "查询结果：" << std::endl;
            for (size_t i = 0; i < keys.size(); ++i) {
                std::cout << "键: " << keys[i] << ", 值: " << values[i] << std::endl;
            }
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "查询失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取查询结果时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForKeys()
{
    std::string keyPrefix = "/test/";

    // 调用keys函数获取以指定key为起始的所有键，返回一个异步任务
    pplx::task<etcd::Response> keysTask = etcd_client.keys(keyPrefix);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = keysTask.get();

        if (response.is_ok()) {
            // 如果操作成功，获取并输出键列表
            const std::vector<std::string>& keys = response.keys();

            std::cout << "获取以 " << keyPrefix << " 为起始的所有键：" << std::endl;
            for (size_t i = 0; i < keys.size(); ++i) {
                std::cout << keys[i] << std::endl;
            }
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "获取键列表失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取键列表时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForKeys_Limit()
{
    std::string keyPrefix = "/test/";
    size_t resultLimit = 5; // 设定只获取5个结果

    // 调用keys函数获取以指定key为起始的部分键，返回一个异步任务
    pplx::task<etcd::Response> keysTask = etcd_client.keys(keyPrefix, resultLimit);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = keysTask.get();

        if (response.is_ok()) {
            // 如果操作成功，获取并输出键列表
            const std::vector<std::string>& keys = response.keys();

            std::cout << "获取以 " << keyPrefix << " 为起始的部分键（最多 " << resultLimit << " 个）：" << std::endl;
            for (size_t i = 0; i < keys.size(); ++i) {
                std::cout << keys[i] << std::endl;
            }
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "获取键列表失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取键列表时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForKeys_Limit_Reversion()
{
    std::string keyPrefix = "/test/";
    size_t resultLimit = 5; // 设定只获取5个结果
    int64_t targetRevision = 2000; // 假设要获取版本为10的相关数据

    // 调用keys函数获取以指定key为起始的部分键（指定版本），返回一个异步任务
    pplx::task<etcd::Response> keysTask = etcd_client.keys(keyPrefix, resultLimit, targetRevision);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = keysTask.get();

        if (response.is_ok()) {
            // 如果操作成功，获取并输出键列表
            const std::vector<std::string>& keys = response.keys();

            std::cout << "获取以 " << keyPrefix << " 为起始的部分键（最多 " << resultLimit << " 个，版本为 " << targetRevision << "）：" << std::endl;
            for (size_t i = 0; i < keys.size(); ++i) {
                std::cout << keys[i] << std::endl;
            }
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "获取键列表失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取键列表时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForKeys_Rangend()
{
    std::string keyStart = "/test/";
    std::string rangeEnd = "/test/key/4";

    // 调用keys函数获取从指定key到range_end之间的所有键，返回一个异步任务
    pplx::task<etcd::Response> keysTask = etcd_client.keys(keyStart, rangeEnd);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = keysTask.get();

        if (response.is_ok()) {
            // 如果操作成功，获取并输出键列表
            const std::vector<std::string>& keys = response.keys();

            std::cout << "获取从 " << keyStart << " 到 " << rangeEnd << "（不包括 " << rangeEnd << "）之间的所有键：" << std::endl;
            for (size_t i = 0; i < keys.size(); ++i) {
                std::cout << keys[i] << std::endl;
            }
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "获取键列表失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取键列表时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForWatch()
{
    std::string keyToWatch = "/test/key";
    bool recursiveWatch = true; // 设置为true表示递归监控，即监控该key及其所有子键
    std::string WatchAction;
    
    // 调用watch函数开始监控指定key及其子键（如果recursive为true），返回一个异步任务
    pplx::task<etcd::Response> watchTask = etcd_client.watch(keyToWatch, recursiveWatch);
    std::cout << "监控到键值对变化3333333333333 " << std::endl;

    try {
        // 获取异步任务的结果，这里的结果会随着被监控的键值对发生变化而不断更新
        etcd::Response response = watchTask.get();
        std::cout << "监控到键值对变化22222222222222222 " << std::endl;

        // 处理监控到的键值对变化情况
        if (response.is_ok()) {
            // 假设这里可以通过response获取到变化的键值对信息，比如新增、修改或删除的键值对
            WatchAction = response.action();
            std::cout << "监控到键值对变化,变化类型为: " << WatchAction << std::endl;
            
            // 这里可以根据response的具体内容进一步处理变化信息，比如输出变化的键、值等信息
            std::cout << "compact_revision = " << "" << response.name() << std::endl;

            if ("create" == WatchAction) {
                std::cout << "新增的键值对：" << std::endl;
                for (auto const& ev : response.events()) {
                    std::cout << "键: " << ev.kv().key() << ", 值: " << ev.kv().as_string() << std::endl;
                    std::cout << "键: " << ev.prev_kv().key() << ", 旧值: " << ev.prev_kv().as_string() << std::endl;
                    std::cout << "键: " << response.value().key() << ", 旧值: " << response.value().as_string() << std::endl;
                }
            }
            else if ("set" == WatchAction)  /* 修改值或者值不变的修改保存操作 */
            {
                std::cout << "更新的键值对：" << std::endl;
                for (auto const& ev : response.events()) {
                    /* 以下几种输出方式均可 */
                    std::cout << "键: " << ev.kv().key() << ", 值: " << ev.kv().as_string() << std::endl;
                    std::cout << "键: " << response.value().key() << ", 值: " << response.value().as_string() << std::endl;
                    std::cout << "键: " << ev.prev_kv().key() << ", 旧值: " << ev.prev_kv().as_string() << std::endl;
                    std::cout << "键: " << response.prev_value().key() << ", 旧值: " << response.prev_value().as_string() << std::endl;

                    /*const std::vector<std::string>& keys = response.keys();*/  /* keys.size()的值为0 */
                    //std::cout << "键: " << response.values().key() << ", 值: " << response.values().as_string() << std::endl;/* 不能这样输出 */
                }
            }
            else if ("delete" == WatchAction)
            {
                std::cout << "删除的键值对：" << std::endl;
                for (auto const& ev : response.events()) {
                    std::cout << "键: " << ev.kv().key() << ", 值: " << ev.kv().as_string() << std::endl;
                    std::cout << "键: " << ev.prev_kv().key() << ", 旧值: " << ev.prev_kv().as_string() << std::endl;
                    std::cout << "键: " << response.value().key() << ", 值: " << response.value().as_string() << std::endl;
                    
                }
            }
            else
            {
                std::cout << "监听键值变化类型为：" << WatchAction << std::endl;
            }
        }
        else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "监控失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } 
    catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取监控结果时发生异常: " << e.what() << std::endl;
    }
    std::cout << "监控到键值对变化11111111111111111 " << std::endl;
}


void FunctionCallForWatch_FromIndex()
{
    std::string keyToWatch = "/test/";
    int64_t startIndex = 10; // 假设之前获取到的某个版本索引，从这里开始监控
    bool recursiveWatch = true; // 设置为true表示递归监控，即监控该key及其所有子键

    // 调用watch函数开始从指定版本索引开始监控指定key及其子键（如果recursive为true），返回一个异步任务
    pplx::task<etcd::Response> watchTask = etcd_client.watch(keyToWatch, startIndex, recursiveWatch);

    try {
        // 获取异步任务的结果，这里的结果会随着被监控的键值对发生变化而不断更新
        etcd::Response response = watchTask.get();

        // 处理监控到的键值对变化情况
        if (response.is_ok()) {
            // 假设这里可以通过response获取到变化的键值对信息，比如新增、修改或删除的键值对
            std::cout << "监控到键值对变化：compact_revision = " << "" << response.compact_revision() << std::endl;/* compact_revision = -1 */
            // 这里可以根据response的具体内容进一步处理变化信息，比如输出变化的键、值等信息
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "监控失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取监控结果时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForLeasegrant()
{
    int leaseTTL = 300; // 设置租约的存活时间为30秒

    // 调用leasegrant函数请求授予租约，返回一个异步任务
    pplx::task<etcd::Response> grantTask = etcd_client.leasegrant(leaseTTL);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = grantTask.get();
        //std::cout << "index = " << response.index() << std::endl;

        if (response.is_ok()) {
            // 如果操作成功，输出相关信息（这里假设可以获取到租约ID等相关信息）
            
            /*const std::vector<int64_t>& leases = response.leases;
            for (int64_t lease : leases) {
                std::cout << "Lease: " << lease << std::endl;
            }*/
            std::cout << "租约授予成功，租约ID: " << response.value().lease() << std::endl;
            
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "租约授予失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取租约授予结果时发生异常: " << e.what() << std::endl;
    }
}

/* 这个函数与上一个函数表象上看，实现功能一样，都是创建一个租约并指定有效时间 */
void FunctionCallForLeasekeepalive()
{
    int leaseTTL = 300; // 设置租约的存活时间为30秒
    #if 0
    // 先请求授予租约
    pplx::task<etcd::Response> grantTask = etcd_client.leasegrant(leaseTTL);

    try {
        // 获取授予租约异步任务的结果
        etcd::Response response = grantTask.get();

        if (response.is_ok()) {
            // 如果租约授予成功，获取租约ID
            int64_t leaseId = response.value().lease();

            // 调用leasekeepalive函数保持租约存活，返回一个异步任务
            pplx::task<std::shared_ptr<etcd::KeepAlive>> keepAliveTask =
                etcd_client.leasekeepalive(leaseTTL);

            try {
                // 获取保持租约存活异步任务的结果，即获取指向KeepAlive对象的共享指针
                std::shared_ptr<etcd::KeepAlive> keepAlivePtr = keepAliveTask.get();

                // 这里可以通过keepAlivePtr进行一些与保持租约存活相关的操作（具体操作取决于KeepAlive类的实现）
                std::cout << "租约保持存活状态，租约ID: " << leaseId << std::endl;
            } catch (const std::exception& e) {
                // 捕获获取保持租约存活异步任务结果过程中可能出现的异常并打印
                std::cout << "获取保持租约存活结果时发生异常: " << e.what() << std::endl;
            }
        } else {
            // 如果租约授予失败，打印错误码和错误信息
            std::cout << "租约授予失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取授予租约异步任务结果过程中可能出现的异常并打印
        std::cout << "获取租约授予结果时发生异常: " << e.what() << std::endl;
    }
    #endif

            // 调用leasekeepalive函数保持租约存活，返回一个异步任务
            pplx::task<std::shared_ptr<etcd::KeepAlive>> keepAliveTask =
                etcd_client.leasekeepalive(leaseTTL);

            try {
                // 获取保持租约存活异步任务的结果，即获取指向KeepAlive对象的共享指针
                std::shared_ptr<etcd::KeepAlive> keepAlivePtr = keepAliveTask.get();

                // 这里可以通过keepAlivePtr进行一些与保持租约存活相关的操作（具体操作取决于KeepAlive类的实现）
                std::cout << "租约保持存活状态，租约ID: " << keepAlivePtr->Lease() << std::endl;/* 需要添加头文件 #include "etcd/KeepAlive.hpp" */
            } catch (const std::exception& e) {
                // 捕获获取保持租约存活异步任务结果过程中可能出现的异常并打印
                std::cout << "获取保持租约存活结果时发生异常: " << e.what() << std::endl;
            }
}

/* 撤销指定ID的租约 */
void FunctionCallForLeaserevoke()
{
    int64_t leaseIdToRevoke = 7587882418572849643; // 假设这是要撤销的租约ID，实际使用时替换为真实ID
    // 调用leaserevoke函数撤销租约，返回一个异步任务
    pplx::task<etcd::Response> revokeTask = etcd_client.leaserevoke(leaseIdToRevoke);
    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = revokeTask.get();
        if (response.is_ok()) {
            std::cout << "租约撤销成功。" << std::endl;
        } else {
            std::cout << "租约撤销失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取租约撤销结果时发生异常: " << e.what() << std::endl;
    }

}

void FunctionCallForLeaseTimeToLive()
{
    // 调用leases函数获取所有租约信息，返回一个异步任务
    pplx::task<etcd::Response> leasesTask = etcd_client.leases();
    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = leasesTask.get();
        if (response.is_ok()) {
            // 假设可以通过response获取租约信息列表，这里只是示例
            const std::vector<int64_t>& leases = response.leases();
            for (int64_t id : leases) {
                int64_t leaseIdToQuery = id;
                
                // 调用leasetimetolive函数查询租约剩余存活时间，返回一个异步任务
                pplx::task<etcd::Response> ttlTask = etcd_client.leasetimetolive(leaseIdToQuery);
                try {
                    // 获取异步任务的结果，即etcd::Response对象
                    etcd::Response response = ttlTask.get();
                    if (response.is_ok()) {
                        // 假设可以通过response获取剩余存活时间，这里只是示例
                        //int remainingTTL = response.leases();
                        //std::cout << "租约剩余存活时间: " << response.leases() << "秒。" << std::endl;
                        int ttl = response.value().ttl();
                        std::cout << "租约ID = " << id << " 的剩余存活时间: " << ttl << "秒。" << std::endl;
                
                    } else {
                        std::cout << "查询租约剩余存活时间失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
                    }
                } catch (const std::exception& e) {
                    // 捕获获取异步任务结果过程中可能出现的异常并打印
                    std::cout << "获取租约剩余存活时间查询结果时发生异常: " << e.what() << std::endl;
                }
            
            }
        } else {
            std::cout << "获取租约信息失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取租约信息结果时发生异常: " << e.what() << std::endl;
    }


}

void FunctionCallForLease()
{
    // 调用leases函数获取所有租约信息，返回一个异步任务
    pplx::task<etcd::Response> leasesTask = etcd_client.leases();
    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = leasesTask.get();
        if (response.is_ok()) {
            // 假设可以通过response获取租约信息列表，这里只是示例
            const std::vector<int64_t>& leases = response.leases();
            std::cout << "所有租约ID列表:" << std::endl;
            for (int64_t id : leases) {
                std::cout << id << std::endl;
            }
        } else {
            std::cout << "获取租约信息失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取租约信息结果时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForAdd_Member()
{
    //std::string newMemberPeerUrls = "http://192.168.56.101:2390";  // 假设这是新成员的对等URL
    std::string newMemberPeerUrls = "http://192.168.2.75:2390";
    bool newMemberIsLearner = false;  // 假设新成员不是学习者模式

    // 调用add_member函数添加新成员，返回一个异步任务
    pplx::task<etcd::Response> addTask = etcd_client.add_member(newMemberPeerUrls, newMemberIsLearner);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = addTask.get();
        if (response.is_ok()) {
            // 假设可以通过response获取新添加成员的ID等信息，这里只是示例
            uint64_t newMemberId = response.member_id();
            std::cout << "成员添加成功，新成员ID: " << newMemberId << std::endl;
        } else {
            std::cout << "成员添加失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取添加成员结果时发生异常: " << e.what() << std::endl;
    }

}

void FunctionCallForList_Member()
{
    // 调用list_member函数获取成员列表，返回一个异步任务
    pplx::task<etcd::Response> listTask = etcd_client.list_member();

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = listTask.get();
        if (response.is_ok()) {
            // 获取成员列表
            const std::vector<etcdv3::Member>& memberList = response.members();
            std::cout << "成员列表信息如下：" << std::endl;
            for (const auto& member : memberList) {
                std::cout << "成员ID: " << member.get_id() << std::endl;
                std::cout << "成员名称: " << member.get_name() << std::endl;
                std::cout << "对等URL列表: ";
                const std::vector<std::string>& peerURLs = member.get_peerURLs();
                for (const auto& url : peerURLs) {
                    std::cout << url << " ";
                }
                std::cout << std::endl;
                std::cout << "客户端URL列表: ";
                const std::vector<std::string>& clientURLs = member.get_clientURLs();
                for (const auto& url : clientURLs) {
                    std::cout << url << " ";
                }
                std::cout << std::endl;
                std::cout << "是否为学习者: " << (member.get_learner()? "是" : "否") << std::endl;
                std::cout << "------------------------" << std::endl;
            }

        } else {
            std::cout << "获取成员列表失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取成员列表结果时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForRemove_Member()
{
    uint64_t memberIdToRemove = 12345;  // 假设这是要移除的成员ID，实际使用时替换为真实ID

    // 调用remove_member函数移除成员，返回一个异步任务
    pplx::task<etcd::Response> removeTask = etcd_client.remove_member(memberIdToRemove);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = removeTask.get();
        if (response.is_ok()) {
            std::cout << "成员移除成功。" << std::endl;
        } else {
            std::cout << "成员移除失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取移除成员结果时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForLock()
{
    std::string lockKey = "/shared_resource/lock";

    // 调用lock函数进行加锁，使用默认租约时间，返回一个异步任务
    pplx::task<etcd::Response> lockTask = etcd_client.lock(lockKey);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lockTask.get();
        if (response.is_ok()) {
            std::cout << "加锁成功。" << std::endl;
        } else {
            std::cout << "加锁失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取加锁结果时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForLock_Sync()
{
    std::string lockKey = "/shared_resource/lock";
    bool syncOption = false; // 假设这里的同步选项暂时没有实际作用，只是示例

    // 调用lock函数进行加锁，使用默认租约时间，返回一个异步任务
    pplx::task<etcd::Response> lockTask = etcd_client.lock(lockKey, syncOption);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lockTask.get();
        if (response.is_ok()) {
            std::cout << "加锁成功。" << std::endl;
        } else {
            std::cout << "加锁失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取加锁结果时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForLock_LeaseTTL()
{
    std::string lockKey = "/shared_resource/lock";
    int leaseTTL = 30; // 设置租约时间为30秒

    // 调用lock函数进行加锁，自定义租约时间，返回一个异步任务
    pplx::task<etcd::Response> lockTask = etcd_client.lock(lockKey, leaseTTL);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lockTask.get();
        if (response.is_ok()) {
            std::cout << "加锁成功，租约时间为 " << leaseTTL << " 秒。" << std::endl;
        } else {
            std::cout << "加锁失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取加锁结果时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForLock_LeaseTTL_Sync()
{
    std::string lockKey = "/shared_resource/lock";
    int leaseTTL = 300; // 设置租约时间为30秒
    bool syncOption = true; // 设置为同步加锁

    // 调用lock函数进行加锁，指定租约时间和同步方式，返回一个异步任务
    pplx::task<etcd::Response> lockTask = etcd_client.lock(lockKey, leaseTTL, syncOption);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lockTask.get();
        if (response.is_ok()) {
            std::cout << "加锁成功，租约时间为 " << leaseTTL << " 秒。" << std::endl;
        } else {
            std::cout << "加锁失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取加锁结果时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForLock_LeaseID()
{
    std::string lockKey = "/shared_resource/lock";
    int64_t leaseId = 12345; // 假设这是已存在的租约ID，实际使用时替换为真实ID

    // 调用lock_with_lease函数进行加锁，使用指定租约ID，返回一个异步任务
    pplx::task<etcd::Response> lockTask = etcd_client.lock_with_lease(lockKey, leaseId);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lockTask.get();
        if (response.is_ok()) {
            std::cout << "加锁成功，使用租约ID： " << leaseId << "。" << std::endl;
        } else {
        std::cout << "加锁失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取加锁结果时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForLock_LeaseID_Sync()
{
    std::string lockKey = "/shared_resource/lock";
    int64_t leaseId = 12345; // 假设这是已存在的租约ID，实际使用时替换为真实ID
    bool syncOption = false; // 设置为异步加锁

    // 调用lock_with_lease函数进行加锁，指定租约ID和异步方式，返回一个异步任务
    pplx::task<etcd::Response> lockTask = etcd_client.lock_with_lease(lockKey, leaseId, syncOption);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lockTask.get();
        if (response.is_ok()) {
            std::cout << "加锁成功，使用租约ID： " << leaseId << "。" << std::endl;
        } else {
        std::cout << "加锁失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取加锁结果时发生异常: " << e.what() << std::endl;
    }
}

void FunctionCallForUnLock()
{
    std::string lockKey = "/shared_resource/lock";

    // 调用unlock函数进行解锁，返回一个异步任务
    pplx::task<etcd::Response> unlockTask = etcd_client.unlock(lockKey);

    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = unlockTask.get();
        if (response.is_ok()) {
            std::cout << "解锁成功。" << std::endl;
        } else {
        std::cout << "解锁失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取解锁结果时发生情况: " << e.what() << std::endl;
    }
}


int main()
{
    /* 以下是etcd::Response中一些函数的使用 */
    //FunctionCallForRead();
    
    //FunctionCallForDelete();  /* etcd.rmdir(start_dir, true) */
    //FunctionCallForDelete1(); /* etcd.rmdir(start_dir, end_dir) */

    //FunctionCallForGet();/* 两个get函数 */
    //FunctionCallForGet_Revision();/* 两个get函数 */
    //FunctionCallForSet();/* 写入或更新一个键值对 */
    //FunctionCallForAdd();
    
    //FunctionCallForModify();
    //FunctionCallForModifyIf_Value();
    //FunctionCallForModifyIf_Index();

    //FunctionCallForLs();
    //FunctionCallForLs_Limit();
    //FunctionCallForLs_Limit_Revision();
    //FunctionCallForLs_Rangend();
    //FunctionCallForLs_Rangend_Limit();
    //FunctionCallForLs_Rangend_Limit_Reversion();

    //FunctionCallForKeys();
    //FunctionCallForKeys_Limit();
    //FunctionCallForKeys_Limit_Reversion();
    //FunctionCallForKeys_Rangend();

    //FunctionCallForWatch();/* 只有当监测的键发生变化，程序才会继续执行后面的内容 */
    //FunctionCallForWatch_FromIndex();
    std::thread t_ClientWatch(FunctionCallForWatch);/* 起线程可以进行下面的内容，当键值发生变化时执行一次，线程结束;若键值一直不变，则监听一直进行 */
    // ----std::thread t_ClientWatch_FromIndex(FunctionCallForWatch_FromIndex);
    FunctionCallForLs();
    
    t_ClientWatch.join();
    // ----t_ClientWatch_FromIndex.join();
    

    //FunctionCallForLeasegrant();
    //FunctionCallForLeasekeepalive();
    //FunctionCallForLeaserevoke();
    //FunctionCallForLeaseTimeToLive();
    //FunctionCallForLease();


    
    return 0;
}


