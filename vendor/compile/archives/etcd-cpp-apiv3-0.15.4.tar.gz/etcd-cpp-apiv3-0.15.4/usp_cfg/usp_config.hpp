#define MAX_NUM_OFKEY   100
#define MAX_LEN_OFKEY   1000
#define PACKED __attribute__ ((packed))


struct PrefixInfo_C {
    int num;
    char key[MAX_LEN_OFKEY];
    char value[MAX_LEN_OFKEY];
    int64_t created_index;
    int64_t modified_index;
    int64_t version;
    int ttl[MAX_NUM_OFKEY];
};

/* 供各服务使用的结构体 */
struct struKeyValueInfo {
    //int num;
    char* Key[100];
    char* Value[100];
    int64_t created_index[100];
    int64_t modified_index[100];
    int64_t version[100];
    int ttl[100];
};

typedef struct {
    char *name;
    int age;
    char *city;
} Person;



typedef struct {
    char* key;
    char* value;
} KeyValue;

typedef struct {
    
    KeyValue* keyValues;
    
} EtcdResponse;


struct ResponseWrapper {
        etcd::Response *presp;
    };


/* 外部调用 */
extern PrefixInfo_C g_struPrefixInfo_C[MAX_NUM_OFKEY];


