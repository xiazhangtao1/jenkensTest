﻿#include <iostream>
#include <memory>
#include <string>
#include <stdlib.h>
#include <functional>
#include <string.h>   /* for strcpy */ 
#include <algorithm>  /* 为了使用 std::copy */ 
#include <json-c/json.h>
#include <cstring>
#include <thread>
#include <chrono>
#include <etcd/SyncClient.hpp>    /* #include "etcd/SyncClient.hpp" */
#include <etcd/Watcher.hpp>       /* #include "etcd/Watcher.hpp" */
#include <etcd/Client.hpp>        /* #include "etcd/Client.hpp" */
#include "usp_config.hpp"

/******************定义全局变量*************************/
std::string etcd_endpoint = "http://192.168.10.35:2489";
etcd::Client etcd_client(etcd_endpoint);
/*******************************************************/
EtcdResponse* UspCfg_Read(char* pKey, unsigned long* pulNum)
{
    unsigned int ulKeyNum = 0;
    std::string keyPrefix(pKey);
    std::string str_key;
    std::string str_value;
    size_t resultLimit;
    //etcd::Response resp = etcd.ls("/test").get();

    pplx::task<etcd::Response> lsTask = etcd_client.ls(keyPrefix);
    try 
    {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response resp = lsTask.get();
        if (resp.is_ok()) 
        {
            EtcdResponse* etcdResponsePtr = new EtcdResponse;
            ulKeyNum = resp.keys().size();

            // 为KeyValue结构体数组分配内存
            etcdResponsePtr->keyValues = new KeyValue[ulKeyNum];
            
            // 为每个KeyValue结构体中的key和value指针分配内存
            for (int i = 0; i < ulKeyNum; i++) {
                str_key   = resp.value(i).key();
                str_value = resp.value(i).as_string();
            
                //std::cout << "i = " << i << ", key = " << str_key << ", value = " << str_value << std::endl;
                
                // 为每个key分配足够的内存
                etcdResponsePtr->keyValues[i].key = new char[str_key.length() + 1];
                
                if (etcdResponsePtr->keyValues[i].key == NULL)
                {
                    // 内存申请失败处理
                    std::cerr << "为etcdResponsePtr->keyValues[" << i << "].key申请内存失败！" << std::endl;
                    // 可以根据具体需求进行进一步的处理，比如释放已经分配的其他相关内存，然后退出程序或采取其他补救措施
            
                    // 示例中简单释放已经分配的keyValues数组内存（如果有），然后退出程序
                    for (int j = 0; j < i; ++j)
                    {
                        if (etcdResponsePtr->keyValues[j].key!= NULL)
                        {
                            delete[] etcdResponsePtr->keyValues[j].key;
                        }
                        if (etcdResponsePtr->keyValues[j].value!= NULL)
                        {
                            delete[] etcdResponsePtr->keyValues[j].value;
                        }
                    }
                    if (etcdResponsePtr->keyValues!= NULL)
                    {
                        delete[] etcdResponsePtr->keyValues;
                    }
                    if (etcdResponsePtr!= NULL)
                    {
                        delete etcdResponsePtr;
                    }
                    return NULL;
                }
                
                // 为每个value分配足够的内存
                etcdResponsePtr->keyValues[i].value = new char[str_value.length() + 1];
            
                if (etcdResponsePtr->keyValues[i].value == NULL)
                {
                    // 内存申请失败处理
                    std::cerr << "为etcdResponsePtr->keyValues[" << i << "].key申请内存失败！" << std::endl;
                    // 可以根据具体需求进行进一步的处理，比如释放已经分配的其他相关内存，然后退出程序或采取其他补救措施
                    
                    for (int j = 0; j < i; ++j)
                    {
                        if (etcdResponsePtr->keyValues[j].key!= NULL)
                        {
                            delete[] etcdResponsePtr->keyValues[j].key;
                        }
                        if (etcdResponsePtr->keyValues[j].value!= NULL)
                        {
                            delete[] etcdResponsePtr->keyValues[j].value;
                        }
                    }
                    if (etcdResponsePtr->keyValues!= NULL) {
                        delete[] etcdResponsePtr->keyValues;
                    }
                    if (etcdResponsePtr!= NULL) {
                        delete etcdResponsePtr;
                    }
                    return NULL;
                }
                
                strcpy(etcdResponsePtr->keyValues[i].key, str_key.c_str());
                strcpy(etcdResponsePtr->keyValues[i].value, str_value.c_str());
                
            }
            *pulNum = ulKeyNum;
            return etcdResponsePtr;

        } 
        else
        {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "列出键值对信息失败，错误码: " << resp.error_code() << ", 错误信息: " << resp.error_message() << std::endl;
            return NULL;
        }
    } 
    catch (const std::exception& e)
    {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取列出信息时发生异常: " << e.what() << std::endl;
        return NULL;
    }
}

void UspCfg_ReleaseEtcdResponseMemory(EtcdResponse* etcdResponsePtr, int n) {
    if (etcdResponsePtr == NULL)
    {
        std::cout << "传入的EtcdResponse指针为空，无需释放内存。" << std::endl;
        return;
    }

    // 释放每个KeyValue结构体中的key和value指针所占用的内存
    for (int i = 0; i < n; i++)
    {
        if (etcdResponsePtr->keyValues[i].key!= NULL)
        {
            // 确保key指针不为空才进行释放操作，避免对空指针执行delete[]导致错误
            delete[] etcdResponsePtr->keyValues[i].key;
            etcdResponsePtr->keyValues[i].key = NULL;
        }

        if (etcdResponsePtr->keyValues[i].value!= NULL)
        {
            delete[] etcdResponsePtr->keyValues[i].value;
            etcdResponsePtr->keyValues[i].value = NULL;
        }
    }

    // 释放KeyValue结构体数组所占用的内存
    if (etcdResponsePtr->keyValues!= NULL)
    {
        delete[] etcdResponsePtr->keyValues;
        etcdResponsePtr->keyValues = NULL;
    }

    // 释放EtcdResponse结构体所占用的内存
    delete etcdResponsePtr;
    etcdResponsePtr = NULL;
}

unsigned int UspCfg_Read_KeyNum(char* pKey, unsigned long *pulNum, void **pOutput)
{
    unsigned int ulRet = 0;
    std::string keyPrefix(pKey);
    
    pplx::task<etcd::Response> lsTask = etcd_client.ls(keyPrefix);
    try 
    {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = lsTask.get();
        if (response.is_ok())
        {
            etcd::Response *ptr = new etcd::Response(response);

            // 如果操作成功，获取并打印键值对中的值
            *pulNum = response.keys().size();
            *pOutput = ptr;
            
            // 验证pOutput是否被正确赋值
            if (pOutput == NULL)
            {
                std::cout << "UspCfgRead: pOutput赋值失败，可能导致后续问题" << std::endl;
                // 可以根据具体需求在这里进行更合适的错误处理，比如抛出异常或者返回特定错误码
                ulRet = 1;
            }
        }
        else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "获取键值对失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
            ulRet = 1;
            pOutput = NULL;
        }
    }
    catch (const std::exception& e)
    {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取键值对时发生异常: " << e.what() << std::endl;
        ulRet = 1;
        pOutput = NULL;
    }

    return ulRet;
}

unsigned int UspCfg_Read_KeyValue(void *voidPtr, unsigned long ulOffset, char **pKey, char **pValue)
{
    unsigned int ulRet = 0;
    std::string str_key;
    std::string str_value;
    etcd::Response *wrapper=(etcd::Response *)voidPtr;
    std::string test = "123";
    char char1[9];
    
    if (wrapper->error_code())
    {
        std::cout << "118" << std::endl;
        ulRet = 1;
    }
    else
    {
        if (wrapper->keys().size() > 0)
        {
            str_key   = wrapper->value(ulOffset).key();
            str_value = wrapper->value(ulOffset).as_string();

            *pKey = new char[str_key.length() + 1];
            if (*pKey == NULL)
            {
                // 内存申请失败处理
                std::cerr << "为pKey分配内存失败！" << std::endl;
                return 1;
            }
            
            *pValue = new char[str_value.length() + 1];
            if (*pValue == NULL) 
            {
                std::cerr << "为pValue分配内存失败！" << std::endl;
                // 如果pKey已经分配成功，需要先释放pKey的内存，避免内存泄漏
                if (*pKey!= NULL) {
                    delete[] *pKey;
                    *pKey = NULL;
                }
                // 同样可以根据具体需求进行进一步处理，比如返回错误码、退出程序等
                return 1;
            }

            strcpy(*pKey, str_key.c_str());
            strcpy(*pValue, str_value.c_str());
            //std::cout << "pKey = " << *pKey << ", pValue = " << *pValue << std::endl;
        }
        else
        {
            ulRet = 1;
        }
    }

    return ulRet;
}

// 释放resp内存的函数
void UspCfg_BufFree_Resp(void *p)
{
    etcd::Response *q = (etcd::Response *)p;
    // 先判断指针是否有效，避免后续对空指针进行操作
    if (!p)
    {
        std::cerr << "传入的指针p为空，无需进行内存释放操作" << std::endl;
        return;
    }
    
    if (q!= NULL)
    {
        delete q;
    }
    else
    {
        return;
    }
}

// 释放key/value内存的函数
void UspCfg_BufFree_KeyValue(char *pKeyOrValue) 
{
    if (pKeyOrValue!= NULL) 
    {
        delete[] pKeyOrValue;
        pKeyOrValue = NULL;
    }
}

/******************************************************************
函数名称: ETCDAPI_PersonToJSON
功能描述: 将Person结构体转换为JSON对象
输入参数: Person *person
输出参数: 无
返回数值: struct json_object *json
修改历史:
 1. 2024-10-23, 周凯, 新生成函数
*******************************************************************/
struct json_object *UspCfg_PersonToJSON(Person *person) {
     /* 创建一个新的JSON对象 */
    struct json_object *json = json_object_new_object();
    
     /* 检查JSON对象是否创建成功 */
    if (json == NULL) {
        fprintf(stderr, "Failed to create JSON object\n");
        return NULL;
    }
    
    /* 添加name字段 */
    if (person->name != NULL) {
        json_object_object_add(json, "name", json_object_new_string(person->name));
    } else {
        json_object_object_add(json, "name", json_object_new_string("")); /* 或者添加null，取决于你的需求 */
    }
    
    /* 添加age字段 */ 
    json_object_object_add(json, "age", json_object_new_int(person->age));
    
    // 添加city字段
    if (person->city != NULL) {
        json_object_object_add(json, "city", json_object_new_string(person->city));
    } else {
        json_object_object_add(json, "city", json_object_new_string(""));
    }
    
    return json;
}

/******************************************************************
函数名称: ETCDAPI_SetKey
功能描述: 写入键值接口函数
输入参数: char* pKey
          char* pValue
输出参数: 无
返回数值: 0: success 1:fail
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
/* int ETCDAPI_SetKey(char* pKey, char* pValue) */
unsigned int UspCfg_Write(char* pKey, const char* pValue)
{
    unsigned int ulRet = 0;
    std::string key_to_put(pKey);
    std::string value_to_put(pValue);

    // 调用put函数添加键值对，返回一个异步任务
    pplx::task<etcd::Response> put_task = etcd_client.put(key_to_put, value_to_put);
    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response response = put_task.get();
        if (response.is_ok()) {
            // 如果操作成功，打印相关信息
            std::cout << "键值对添加成功！" << std::endl;
            std::cout << "添加后的键值对：键 = " << key_to_put << ", 值 = " << value_to_put << std::endl;

        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "键值对添加失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
            ulRet = 1;
        }
    } catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "添加键值对时发生异常: " << e.what() << std::endl;
        ulRet = 1;
    }
    return ulRet;
}

/******************************************************************
函数名称: UspCfg_Delete_Key_Recursive
功能描述: 删除键 接口函数
输入参数: char* pKey
输出参数: 无
返回数值: 0: success 1:fail
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
unsigned int UspCfg_Delete_Key_Recursive(char* pKey, bool recursive)
{
    //etcd_client.set("/test/delete", "foo");
    std::string key_Delete(pKey); /* 一键多值,如何删除该键的某个值 ps:这种情况是不是可以理解为修改键 */

    // 调用rmdir函数获取键值对，返回一个异步任务
    pplx::task<etcd::Response> rmdir_task = etcd_client.rmdir(key_Delete, recursive);
    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response resp = rmdir_task.get();
        if (resp.is_ok()) {
            // 如果操作成功，获取并打印键值对中的值
            for (int i = 0; i < resp.keys().size(); ++i)
            {
                std::cout << "Delete key: " << resp.value(i).key() << ", value = " << resp.value(i).as_string() << std::endl;
            }
            return 0;
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "获取键值对失败，错误码: " << resp.error_code() << ", 错误信息: " << resp.error_message() << std::endl;
            return 1;
        }
    }
    catch (const std::exception& e)
    {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取键值对时发生异常: " << e.what() << std::endl;
        return 1;
    }
}


/******************************************************************
函数名称: UspCfg_Delete_Key_Rangend
功能描述: 删除键 接口函数
输入参数: char* pKey
输出参数: 无
返回数值: 0: success 1:fail
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
unsigned int UspCfg_Delete_Key_Rangend(char* pKeyStart, char* pKeyEnd)
{
    std::string start_dir(pKeyStart);
    std::string end_dir(pKeyEnd);
    
    //etcd::Response resp = etcd.rm(start_dir).get();/* 删除单个指定的键值对 */

    // 调用rmdir函数获取键值对，返回一个异步任务
    pplx::task<etcd::Response> rmdir_task = etcd_client.rmdir(start_dir, end_dir);
    try {
        // 获取异步任务的结果，即etcd::Response对象
        etcd::Response resp = rmdir_task.get();
        if (resp.is_ok()) {
            // 如果操作成功，获取并打印键值对中的值
            for (int i = 0; i < resp.keys().size(); ++i)
            {
                std::cout << "Delete key: " << resp.value(i).key() << ", value = " << resp.value(i).as_string() << std::endl;
            }
            return 0;
        } else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "获取键值对失败，错误码: " << resp.error_code() << ", 错误信息: " << resp.error_message() << std::endl;
            return 1;
        }
    }
    catch (const std::exception& e)
    {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取键值对时发生异常: " << e.what() << std::endl;
        return 1;
    }
}

unsigned int UspCfg_Watch(const char* pKey, bool recursive)
{
    unsigned int ulRet = 0;
    std::string keyToWatch(pKey);
    std::string WatchAction;
    
    // 调用watch函数开始监控指定key及其子键（如果recursive为true），返回一个异步任务
    pplx::task<etcd::Response> watchTask = etcd_client.watch(keyToWatch, recursive);

    try {
        // 获取异步任务的结果，这里的结果会随着被监控的键值对发生变化而不断更新
        etcd::Response response = watchTask.get();

        // 处理监控到的键值对变化情况
        if (response.is_ok()) {
            // 假设这里可以通过response获取到变化的键值对信息，比如新增、修改或删除的键值对
            WatchAction = response.action();
            std::cout << "监控到键值对变化,变化类型为: " << WatchAction << std::endl;

            std::cout << "更新的键值对：" << std::endl;
            for (auto const& ev : response.events()) {
                /* 以下几种输出方式均可 */
                std::cout << "键: " << ev.kv().key() << ", 值: " << ev.kv().as_string() << std::endl;
                std::cout << "键: " << response.value().key() << ", 值: " << response.value().as_string() << std::endl;
                std::cout << "键: " << ev.prev_kv().key() << ", 旧值: " << ev.prev_kv().as_string() << std::endl;
                std::cout << "键: " << response.prev_value().key() << ", 旧值: " << response.prev_value().as_string() << std::endl;
            }
            ulRet = 0;
        }
        else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "监控失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
            ulRet = 1;
        }
    } 
    catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取监控结果时发生异常: " << e.what() << std::endl;
        ulRet = 1;
    }

    return 1;
}

EtcdResponse* UspCfg_Watch_KeyValue(const char* pKey, bool recursive, unsigned long* pulNum)
{
    unsigned int ulKeyNum = 0;
    unsigned int i = 0;
    std::string keyToWatch(pKey);
    std::string str_key;
    std::string str_value;
    std::string WatchAction;
    
    // 调用watch函数开始监控指定key及其子键（如果recursive为true），返回一个异步任务
    pplx::task<etcd::Response> watchTask = etcd_client.watch(keyToWatch, recursive);

    try {
        // 获取异步任务的结果，这里的结果会随着被监控的键值对发生变化而不断更新
        etcd::Response response = watchTask.get();

        // 处理监控到的键值对变化情况
        if (response.is_ok()) {
            EtcdResponse* etcdResponsePtr = new EtcdResponse;

            const auto& events = response.events();
            ulKeyNum = events.size();

            // 为KeyValue结构体数组分配内存
            etcdResponsePtr->keyValues = new KeyValue[ulKeyNum];
            
            // 假设这里可以通过response获取到变化的键值对信息，比如新增、修改或删除的键值对
            WatchAction = response.action();
            std::cout << "监控到键值对变化,变化类型为: " << WatchAction << ", ulKeyNum = " << ulKeyNum << std::endl;

            #if 1
            for (auto const& ev : response.events()) {
                /* 以下几种输出方式均可 */
                std::cout << "键: " << ev.kv().key() << ", 值: " << ev.kv().as_string() << std::endl;
                std::cout << "键: " << response.value().key() << ", 值: " << response.value().as_string() << std::endl;
                std::cout << "键: " << ev.prev_kv().key() << ", 旧值: " << ev.prev_kv().as_string() << std::endl;
                std::cout << "键: " << response.prev_value().key() << ", 旧值: " << response.prev_value().as_string() << std::endl;

                str_key   = response.value().key();
                str_value = response.value().as_string();
                //std::cout << "i = " << i << ", key = " << str_key << ", value = " << str_value << std::endl;
                
                // 为每个key分配足够的内存
                etcdResponsePtr->keyValues[i].key = new char[str_key.length() + 1];
                
                if (etcdResponsePtr->keyValues[i].key == NULL)
                {
                    // 内存申请失败处理
                    std::cerr << "为etcdResponsePtr->keyValues[" << i << "].key申请内存失败！" << std::endl;
                    // 可以根据具体需求进行进一步的处理，比如释放已经分配的其他相关内存，然后退出程序或采取其他补救措施
            
                    // 示例中简单释放已经分配的keyValues数组内存（如果有），然后退出程序
                    for (int j = 0; j <= i; j++)
                    {
                        if (etcdResponsePtr->keyValues[j].key!= NULL)
                        {
                            delete[] etcdResponsePtr->keyValues[j].key;
                        }
                        if (etcdResponsePtr->keyValues[j].value!= NULL)
                        {
                            delete[] etcdResponsePtr->keyValues[j].value;
                        }
                    }
                    if (etcdResponsePtr->keyValues!= NULL)
                    {
                        delete[] etcdResponsePtr->keyValues;
                    }
                    if (etcdResponsePtr!= NULL)
                    {
                        delete etcdResponsePtr;
                    }
                    return NULL;
                }
                
                // 为每个value分配足够的内存
                etcdResponsePtr->keyValues[i].value = new char[str_value.length() + 1];
            
                if (etcdResponsePtr->keyValues[i].value == NULL)
                {
                    // 内存申请失败处理
                    std::cerr << "为etcdResponsePtr->keyValues[" << i << "].key申请内存失败！" << std::endl;
                    // 可以根据具体需求进行进一步的处理，比如释放已经分配的其他相关内存，然后退出程序或采取其他补救措施
                    
                    for (int j = 0; j <= i; j++)
                    {
                        if (etcdResponsePtr->keyValues[j].key!= NULL)
                        {
                            delete[] etcdResponsePtr->keyValues[j].key;
                        }
                        if (etcdResponsePtr->keyValues[j].value!= NULL)
                        {
                            delete[] etcdResponsePtr->keyValues[j].value;
                        }
                    }
                    if (etcdResponsePtr->keyValues!= NULL) {
                        delete[] etcdResponsePtr->keyValues;
                    }
                    if (etcdResponsePtr!= NULL) {
                        delete etcdResponsePtr;
                    }
                    return NULL;
                }
                
                strcpy(etcdResponsePtr->keyValues[i].key, str_key.c_str());
                strcpy(etcdResponsePtr->keyValues[i].value, str_value.c_str());
                i++;
            }
            #endif
            
            *pulNum = ulKeyNum;
            return etcdResponsePtr;
            
        }
        else {
            // 如果操作失败，打印错误码和错误信息
            std::cout << "监控失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
            return NULL;
        }
    } 
    catch (const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取监控结果时发生异常: " << e.what() << std::endl;
        return NULL;
    }
}

unsigned int FunctionCallForRead_KeyValue()
{
    char szPath[256];
    strcpy(szPath, "/");
    unsigned long ulNum = 0;
    unsigned long uli;

    EtcdResponse* etcdResponsePtr = NULL;
    
    etcdResponsePtr = UspCfg_Read(szPath, &ulNum);
    if (NULL == etcdResponsePtr)
    {
        return 1;
    }
    else
    {
        std::cout << "---LINE:" << __LINE__ << ",function:" << __func__ << std::endl;
        for (uli = 0;uli < ulNum;uli++)
        {
            std::cout << "---LINE:" << __LINE__ << ", i = " << uli << ", key = " << etcdResponsePtr->keyValues[uli].key 
                      << ", value = " << etcdResponsePtr->keyValues[uli].value << std::endl;
        }
        UspCfg_ReleaseEtcdResponseMemory(etcdResponsePtr, ulNum);
        return 0;
    }
}

void FunctionCallForRead_KeyNum()
{
    const int numIterations = 5;  // 设置循环调用的次数
    void *pOutputInfo;
    unsigned long ulNum = 0;
    char szPath[256];
    unsigned int ulRet;
    unsigned int ulRet1;
    char *pRead_Key = NULL;
    char *pRead_Value = NULL;
    
    strcpy(szPath, "/");
    
    ulRet = UspCfg_Read_KeyNum(szPath, &ulNum, &pOutputInfo);
    
    if ((0 == ulRet) && (pOutputInfo))
    {
        std::cout << "---LINE:" << __LINE__ << ",function:" << __func__ << std::endl;
        for (int i = 0; i < ulNum; ++i)
        {
            ulRet1 = UspCfg_Read_KeyValue(pOutputInfo, i, &pRead_Key, &pRead_Value);
            if (ulRet1 == 1)
            {
                std::cout << "在读取键值对时出现错误，索引为：" << i << std::endl;
                // 可以根据具体需求决定是否继续循环或者采取其他措施
            }
            else
            {
                if ((pRead_Key != NULL) && (pRead_Value != NULL))
                {
                    std::cout << "i = " << i << ", pRead_Key = " << pRead_Key << ", pRead_Value = " << pRead_Value << std::endl;
                }
                else
                {
                    std::cout << "NULL " << std::endl;
                }
            }
        }

        // 释放内存
        UspCfg_BufFree_Resp(pOutputInfo);
        UspCfg_BufFree_KeyValue(pRead_Key);
        UspCfg_BufFree_KeyValue(pRead_Value);
    }
    else
    {
        // 当UspCfgRead函数返回错误时，释放可能已经分配的pOutputInfo相关内存
        if (pOutputInfo!= NULL)
        {
            UspCfg_BufFree_Resp(pOutputInfo);
        }
    }
}


unsigned int FunctionCallForWrite()
{
    unsigned int ulRet = 0;  /* UNIT32 */
    char szPath[256];
    char Value[256] = "hello";
    
    strcpy(szPath, "/test/write");
    std::cout << "---LINE:" << __LINE__ << ",function:" << __func__ << std::endl;
    ulRet = UspCfg_Write(szPath, Value);
    return ulRet;
}

unsigned int FunctionCallForWrite_Json()
{
    char Key[MAX_LEN_OFKEY] = "/test/write/json";
    char Value[MAX_LEN_OFKEY] = "API modify";
    unsigned int ulRet = 0;
    struct json_object *json;
    const char *jsonString;
    char name[10] = "John Doe";
    char city[10] = "New York";
    
    Person person;  /* 创建一个Person实例  Person person = {"John Doe", 30, "New York"};*/
    person.name = name;
    person.age  = 30;
    person.city = city;
    
    std::cout << "---LINE:" << __LINE__ << ",function:" << __func__ << std::endl;
    
    /* 将Person实例转换为JSON对象 */
    json = UspCfg_PersonToJSON(&person);
    
    /* 检查转换是否成功 */
    if (json != NULL)
    {
        jsonString = json_object_to_json_string(json);
        
        /* 检查字符串是否生成成功 */
        if (jsonString != NULL)
        {
            //printf("%s\n", jsonString);
            ulRet = UspCfg_Write(Key, jsonString);
            if (0 == ulRet)
            {
                std::cout << "SET Successful " << std::endl;
            }
        } 
        else 
        {
            fprintf(stderr, "Failed to convert JSON object to string\n");
            ulRet = 1;
        }
    
        /* 释放JSON对象内存 */
        json_object_put(json);
    }
    else
    {
        ulRet = 1;
    }

    return ulRet;
}


void FunctionCallForDelete_Key_Recursive()
{
    unsigned int ulRet = 0;
    char szPath[256];
    bool recursive;
    
    strcpy(szPath, "/test/key");
    recursive = false; /* true:递归删除 false:非递归删除 */

    std::cout << "---LINE:" << __LINE__ << ",function:" << __func__ << std::endl;
    
    ulRet = UspCfg_Delete_Key_Recursive(szPath, recursive);
    if (ulRet == 0)
    {
        std::cout << "delet succsess" << std::endl;
    }
}

void FunctionCallForDelete_Key_Rangend()
{
    unsigned int ulRet = 0;
    char szPathStart[256];
    char szPathEnd[256];
    
    strcpy(szPathStart, "/test/key3");
    strcpy(szPathEnd, "/test/key3");
    
    std::cout << "---LINE:" << __LINE__ << ",function:" << __func__ << std::endl;
    
    ulRet = UspCfg_Delete_Key_Rangend(szPathStart, szPathEnd);
    if (ulRet == 0)
    {
        std::cout << "delet succsess" << std::endl;
    }
}

unsigned int FunctionCallForWatch()
{
    unsigned int ulRet = 0;
    char szPath[256];
    bool recursive = true;
    strcpy(szPath, "/");
    std::cout << "---LINE:" << __LINE__ << ",function:" << __func__ << std::endl;

    ulRet = UspCfg_Watch(szPath, recursive);
    if (ulRet == 0)
    {
        std::cout << "watch succsess" << std::endl;
    }
    return ulRet;
}

unsigned int FunctionCallForWatch_KeyValue()
{
    char szPath[256];
    bool recursive = true;
    unsigned long ulNum = 0;
    unsigned long uli;
    
    EtcdResponse* etcdResponsePtr = NULL;

    strcpy(szPath, "/");
    
    etcdResponsePtr = UspCfg_Watch_KeyValue(szPath, recursive, &ulNum);
    if (NULL == etcdResponsePtr)
    {
        return 1;
    }
    else
    {
        std::cout << "---LINE:" << __LINE__ << ",function:" << __func__ << std::endl;
        for (uli = 0;uli < ulNum;uli++)
        {
            std::cout << ", i = " << uli << ", key = " << etcdResponsePtr->keyValues[uli].key 
                      << ", value = " << etcdResponsePtr->keyValues[uli].value << std::endl;
        }
        UspCfg_ReleaseEtcdResponseMemory(etcdResponsePtr, ulNum);
        return 0;
    }
}

int main()
{
    //FunctionCallForWatch();
    std::thread t_ClientWatch(FunctionCallForWatch_KeyValue);  /* watch线程 */
    
    FunctionCallForRead_KeyNum();
    FunctionCallForRead_KeyValue();
    //FunctionCallForWatch();
    //FunctionCallForWrite();
    //FunctionCallForWrite_Json();
    t_ClientWatch.join();  /* watch线程 */

    

    //FunctionCallForDelete_Key_Recursive();
    //FunctionCallForDelete_Key_Rangend();

    return 0;
}

