﻿#include <iostream>
#include <thread>
#include <pplx/pplx.h>
#include <etcd/Watcher.hpp>       /* #include "etcd/Watcher.hpp" */
#include <etcd/Client.hpp>        /* #include "etcd/Client.hpp" */



std::string etcd_endpoint = "http://192.168.10.35:2489";
etcd::Client etcd_client(etcd_endpoint);

// 处理键值变化的回调函数
void keyValueChangeCallback(etcd::Response response) {
    if (response.is_ok()) {
        std::cout << "范围内的键值发生变化，新值为: " << response.value().as_string() << std::endl;
    } else {
        std::cout << "获取键值变化信息失败，错误码: " << response.error_code() << ", 错误信息: " << response.error_message() << std::endl;
    }
}

// 处理等待结果的回调函数
void waitResultCallback(bool result) {
    if (result) {
        std::cout << "等待成功，已获取到范围内键值变化。" << std::endl;
    } else {
        std::cout << "等待超时或出现其他问题，未获取到范围内键值变化。" << std::endl;
    }
}

void FunctionCallForWatcher_Recursive()
{
    std::string keyToWatch = "/config/some_setting";
    bool recursiveFlag = false;  // 只监视单个键，不递归

    // 创建Watcher
    //etcd::Watcher watcher(etcd_client, keyToWatch, keyValueChangeCallback, waitResultCallback, recursiveFlag);
    etcd::Watcher watcher(etcd_client, keyToWatch, keyValueChangeCallback, recursiveFlag);

    // 模拟主程序持续运行，这里让程序暂停一段时间
    std::this_thread::sleep_for(std::chrono::seconds(30));
}

void FunctionCallForWatcher_Range_end()
{
    std::string startKeyToWatch = "/users/user10";
    std::string endKeyToWatch = "/users/user20";
    int64_t startIndex = 100;  // 假设从索引100开始监视

    // 创建Watcher对象
    etcd::Watcher watcher(etcd_client, startKeyToWatch, endKeyToWatch, keyValueChangeCallback, waitResultCallback);
    //etcd::Watcher watcher(etcd_client, startKeyToWatch, endKeyToWatch, startIndex, keyValueChangeCallback, waitResultCallback);
    //etcd::Watcher watcher(etcd_client, startKeyToWatch, endKeyToWatch, keyValueChangeCallback);
    //etcd::Watcher watcher(etcd_client, startKeyToWatch, endKeyToWatch, startIndex, keyValueChangeCallback);

    // 模拟主程序持续运行，这里让程序暂停一段时间
    std::this_thread::sleep_for(std::chrono::seconds(30));
}

void FunctionCallForWatcher_FromIndex_Recursive()
{
    std::string keyToWatch = "/logs/config";
    int64_t startIndex = 10;  // 假设从索引100开始监视
    bool recursiveFlag = false;  // 只监视单个键，不递归

    // 创建Watcher对象
    etcd::Watcher watcher(etcd_client, keyToWatch, startIndex, keyValueChangeCallback, waitResultCallback, recursiveFlag);
    //etcd::Watcher watcher(etcd_client, keyToWatch, startIndex, keyValueChangeCallback, recursiveFlag);

    // 模拟主程序持续运行，这里让程序暂停一段时间
    std::this_thread::sleep_for(std::chrono::seconds(30));
}

#if 0
void onWatchResult(etcd::Response response)
{
    if (response.is_ok())
    {
        if (response.events().size() > 0)
        {
            std::cout << "检测到键值发生变化：" << std::endl;
            for (auto const& ev : response.events())
            {
                std::cout << ", 键：" << ev.kv().key() << std::endl;

            }
        }
        else
        {
            std::cout << "开始监视成功，但尚未检测到键值变化。" << std::endl;
        }
    }
    else
    {

    }
}

void FunctionCallForAsyncWatchAction()
{
    std::string etcd_endpoint1 = "http://192.168.10.35:2489";
    etcd::Client etcd_client1(etcd_endpoint);

    std::string keyToWatch = "/test/add";
    bool recursiveFlag = false;  // 只监视单个键，不递归

    etcdv3::AsyncWatchAction watchAction(etcd_client1, keyToWatch, recursiveFlag);

    pplx::task<etcd::Response> watchTask = watchAction.start_timepoint();

    try 
    {
        etcd::Response response = watchTask.get();
        onWatchResult(response);

        watchAction.CancelWatch();
        try{
            response = watchTask.get();
            onWatchResult(response);

        }
        catch(const std::exception& e) {
            // 捕获获取异步任务结果过程中可能出现的异常并打印
            std::cout << "在取消监视后获取任务结果时发生异常: " << e.what() << std::endl;
        }

    }
    catch(const std::exception& e) {
        // 捕获获取异步任务结果过程中可能出现的异常并打印
        std::cout << "获取监控结果时发生异常: " << e.what() << std::endl;
    }

}
#endif

int main()
{
    //FunctionCallForWatcher_Recursive();
    std::thread t_ClientWatch(FunctionCallForWatcher_Recursive);  /* watch线程 */

    std::cout << "@@@@@@@@@@@@@@@@@@" << std::endl;
    t_ClientWatch.join();  /* watch线程 */

    //FunctionCallForWatcher_FromIndex_Recursive();


    
    return 0;
}


