
#include <string>
#define MAX_NUM_OFKEY   100
#define MAX_LEN_OFKEY   1000

struct PrefixInfo {
    int num;
    std::string key[MAX_NUM_OFKEY];
    std::string as_string[MAX_NUM_OFKEY];
    int64_t created_index[MAX_NUM_OFKEY];
    int64_t modified_index[MAX_NUM_OFKEY];
    int64_t version[MAX_NUM_OFKEY];
    int ttl[MAX_NUM_OFKEY];
};

struct PrefixInfo_C {
    int num;
    char* key[MAX_NUM_OFKEY];
    char* value[MAX_NUM_OFKEY];
    int64_t created_index[MAX_NUM_OFKEY];
    int64_t modified_index[MAX_NUM_OFKEY];
    int64_t version[MAX_NUM_OFKEY];
    int ttl[MAX_NUM_OFKEY];
};


struct Key_Value_addr {
    char cstr_key[MAX_LEN_OFKEY];    // 分配足够的空间来存储字符串及其结尾的 null 字符
    char cstr_value[MAX_LEN_OFKEY];  // 分配足够的空间来存储字符串及其结尾的 null 字符
};



enum ClientAPI_CMD {
    INITIAL,
    GET,
    SET,
    DELETE,
    WATCH
};

/* 供各服务使用的结构体 */
struct struKeyValueInfo {
    int num;
    char* Key[100];
    char* Value[100];
    int64_t created_index[100];
    int64_t modified_index[100];
    int64_t version[100];
    int ttl[100];
};

typedef struct {
    char *name;
    int age;
    char *city;
} Person;

extern struKeyValueInfo g_struOutputInfo;

/* 外部调用 */
extern PrefixInfo g_struPrefixInfo;
extern PrefixInfo_C g_struPrefixInfo_C;
extern Key_Value_addr g_Key_Value_addr[MAX_NUM_OFKEY];
extern void print_struPrefixInfo();
extern void CppToC_struPrefixInfo();


extern void callbackFunction();

