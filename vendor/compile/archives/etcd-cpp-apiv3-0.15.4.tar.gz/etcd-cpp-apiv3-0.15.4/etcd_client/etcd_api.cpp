#include <iostream>
#include <string>
#include <stdlib.h>
#include <functional>

#include <string.h>   /* for strcpy */ 
#include <algorithm>  /* 为了使用 std::copy */ 

#include <cstring>
#include <thread>
#include "etcd/SyncClient.hpp"
#include "etcd/Watcher.hpp"
#include "etcd/Client.hpp"
#include "etcd_api.hpp"

#include <json-c/json.h>

/* 函数声明 */
void Client_Response_watch(etcd::Response const& resp);

/******************定义全局变量*************************/
PrefixInfo g_struPrefixInfo;     /* CPP形式存储 */
PrefixInfo_C g_struPrefixInfo_C; /* C形式存储 */
PrefixInfo_C g_struPrefixInfo_C_Backup; /* C形式存储，备份存储，供API读取 */
Key_Value_addr g_Key_Value_addr[MAX_NUM_OFKEY];
struKeyValueInfo g_struOutputInfo;

static const std::string etcd_url = etcdv3::detail::resolve_etcd_endpoints("http://192.168.2.75:2389");
/*******************************************************/


/******************************************************************
函数名称: ETCDClient_Initial
功能描述: ETCD Client初始化函数
输入参数: 无
输出参数: 无
返回数值: void
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
void ETCDClient_Initial()
{
     /* 读取server ip地址 */ 
    
}

/******************************************************************
函数名称: ETCDAPI_GetKey
功能描述: 读取键值接口函数
输入参数: char* pKey
          struKeyValueInfo* pstruOutputInfo
输出参数: struKeyValueInfo* pstruOutputInfo
返回数值: 无
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
int ETCDAPI_GetKey(char* pKey, struKeyValueInfo* pstruOutputInfo)
{  
    int  num;
    int  OutputInfoNum;
    int  i;
    int  LenthofKey;
    
    LenthofKey = strlen(pKey);
    num = g_struPrefixInfo_C_Backup.num;
    
    std::cout << "PrefixInfoNum = " << g_struPrefixInfo_C_Backup.num << ", Key = " << pKey << ", LenthofKey = " << LenthofKey << std::endl;
    for (i = 0;i < num; i++)
    {        
        if (strncmp(g_struPrefixInfo_C_Backup.key[i], pKey, LenthofKey) == 0)
        {           
            OutputInfoNum = pstruOutputInfo->num;
            pstruOutputInfo->Key[OutputInfoNum] = g_struPrefixInfo_C_Backup.key[i];
            pstruOutputInfo->Value[OutputInfoNum] = g_struPrefixInfo_C_Backup.value[i];
            pstruOutputInfo->num++;
        }
        else
        {
            continue;
        } 
    }    
    /* 如何表示失败 */
    return 0;
}

/******************************************************************
函数名称: ETCDAPI_PersonToJSON
功能描述: 将Person结构体转换为JSON对象
输入参数: Person *person
输出参数: 无
返回数值: struct json_object *json
修改历史:
 1. 2024-10-23, 周凯, 新生成函数
*******************************************************************/
struct json_object *ETCDAPI_PersonToJSON(Person *person) {
     /* 创建一个新的JSON对象 */
    struct json_object *json = json_object_new_object();
    
     /* 检查JSON对象是否创建成功 */
    if (json == NULL) {
        fprintf(stderr, "Failed to create JSON object\n");
        return NULL;
    }
    
    /* 添加name字段 */
    if (person->name != NULL) {
        json_object_object_add(json, "name", json_object_new_string(person->name));
    } else {
        json_object_object_add(json, "name", json_object_new_string("")); /* 或者添加null，取决于你的需求 */
    }
    
    /* 添加age字段 */ 
    json_object_object_add(json, "age", json_object_new_int(person->age));
    
    // 添加city字段
    if (person->city != NULL) {
        json_object_object_add(json, "city", json_object_new_string(person->city));
    } else {
        json_object_object_add(json, "city", json_object_new_string(""));
    }
    
    return json;
}

/******************************************************************
函数名称: ETCDAPI_SetKey
功能描述: 写入键值接口函数
输入参数: char* pKey
          char* pValue
输出参数: 无
返回数值: 0: success 1:fail
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
/* int ETCDAPI_SetKey(char* pKey, char* pValue) */
int ETCDAPI_SetKey(char* pKey, const char* pValue)
{
    std::string key_Set(pKey);
    std::string value(pValue);
    etcd::SyncClient client(etcd_url);
    
    etcd::Watcher w(client, key_Set, std::move(Client_Response_watch), false);
    
    etcd::Response resp = client.put(key_Set, value);
    if (resp.error_code())
    {
        std::cout << "set " << resp.watch_id() << " fails with "
                  << resp.error_code() << ": " << resp.error_message() << std::endl;
        return 1;
    }
    else 
    {
        //std::cout << "SET Successful " << std::endl;
        return 0;
    }
    
    #if 0  /* 如下watch函数调用需要有延时的两行代码 */
    std::cout << "Setting the key pair start" << std::endl;
    std::string key_Set(pKey);
    std::string value(pValue);
    etcd::SyncClient client(etcd_url);

    auto wait_cb = [&](bool) {};
    auto current_index = client.head().index();
    std::cout << "Current index " << current_index << std::endl;
    
    etcd::Watcher w(client, key_Set, current_index, std::move(Client_Response_watch), std::move(wait_cb), false);
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
    client.put(key_Set, value);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    #endif
    
    #if 0
    etcd::Client etcd("http://192.168.2.75:2389");
    // 设置键值对
    etcd::Response response = etcd.set(pKey, pValue).get();
 
    // 检查响应状态
    if (!response.is_ok()) {
        std::cerr << "设置键值对失败: " << response.error_code() << " " << response.error_message() << std::endl;
        return 1;
    }
 
    // 打印响应结果
    std::cout << "Setting the key pair Success" << std::endl;
    #endif

    return 0;
}

/******************************************************************
函数名称: ETCDAPI_DeleteKey
功能描述: 删除键 接口函数
输入参数: char* pKey
输出参数: 无
返回数值: 0: success 1:fail
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
int ETCDAPI_DeleteKey(char* pKey)
{
    /* etcd::Client etcd("http://192.168.2.75:2389"); */
    etcd::Client etcd(etcd_url);
    /* etcd.set("/test/key1", "foo"); */

    std::string key_Delete(pKey);
    //std::string value(pValue); /* 一键多值,如何删除该键的某个值 */
    etcd::SyncClient client(etcd_url);
    
    etcd::Watcher w(client, key_Delete, std::move(Client_Response_watch), false);

    etcd::Response resp = etcd.rmdir(key_Delete, true).get();
    
    if (resp.error_code())
    {
        std::cout << "delet " << resp.watch_id() << " fails with "
                  << resp.error_code() << ": " << resp.error_message() << std::endl;
        return 1;
    }
    else
    {
        for (unsigned long i = 0; i < resp.keys().size(); ++i)
        {
            std::cout << "Delete key: " << resp.value(i).key() << ", value = " << resp.value(i).as_string() << std::endl;
        }
        return 0;
    }

}

/******************************************************************
函数名称: ETCDAPI_Response_watch
功能描述: 
输入参数: 
输出参数: 
返回数值: 
修改历史:
 1. 2024-10-24, 周凯, 新生成函数,功能待完善
*******************************************************************/
void ETCDAPI_Response_watch(etcd::Response const& resp)
{
    std::cout << "--------------ETCDAPI_Response_watch----------------" << std::endl;
    if (resp.error_code()) 
    {
        std::cout << "Watcher " << resp.watch_id() << " fails with "
                  << resp.error_code() << ": " << resp.error_message() << std::endl;
    }
    else
    {
        std::cout << "Watcher " << resp.watch_id() << " responses with " << resp.action() << " " << resp.value().as_string() << std::endl;
        std::cout << "Previous value: " << resp.prev_value().as_string() << std::endl;

        //std::cout << "Events size: " << resp.events().size() << std::endl;
        for (auto const& ev : resp.events()) 
        {
            //std::cout << "Value change in events: " << static_cast<int>(ev.event_type()) << std::endl;
            //std::cout << "Watch '" << ev.kv().key() << "'. ModifedRevision : " << ev.kv().modified_index()
            //        << "', Vision : " << ev.kv().version() << ", value = " << ev.kv().as_string() << std::endl;
        }
    }
}

/******************************************************************
函数名称: ETCDAPI_WatchKey
功能描述: 订阅键 接口函数
输入参数: char* pKey
输出参数: 无
返回数值: 0: success 1:fail
修改历史:
1. 2024-10-24, 周凯, 暂时不支持该功能
*******************************************************************/
int ETCDAPI_WatchKey(const char* pKey)
{
    while (1)
    {
        std::string key_Watch(pKey);
        etcd::Watcher watcher(etcd_url, key_Watch, ETCDAPI_Response_watch, true);
        getchar();
    }

    return 0;
}


/******************************************************************
函数名称: threadFunction_ClientAPI
功能描述: 调用API接口函数的线程
输入参数: ClientAPI_CMD cmd
输出参数: 无
返回数值: void
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
void ETCDAPI_threadFunction_all(ClientAPI_CMD cmd)
{
    int  num;
    int  OutputInfoNum;
    int  i;
    int  LenthofKey;
    
    if (cmd == INITIAL)
    {
        /* 指令初始值，不做任何处理 */  
    }
    else if (cmd == GET)
    {
        char Key[MAX_LEN_OFKEY] = "/test";
    
        ETCDAPI_GetKey(Key, &g_struOutputInfo);
        std::cout << "File: " << __FILE__ << ", Line: " << __LINE__ << ", cmd: GET" << std::endl;
        for (int i = 0;i < g_struOutputInfo.num;i++)
        {
            std::cout << "i = " << i << ", Key = " << g_struOutputInfo.Key[i] << ", Value = " << g_struOutputInfo.Value[i] << std::endl;
        }
    }
    else if (cmd == SET)
    {
        std::cout << "File: " << __FILE__ << ", Line: " << __LINE__ << ", cmd: SET" << std::endl;
        char Key[MAX_LEN_OFKEY] = "/test/key/set";
        char Value[MAX_LEN_OFKEY] = "API modify";
        int ret = 0xff;
        struct json_object *json;
        const char *jsonString;
        char name[10] = "John Doe";
        char city[10] = "New York";
        
        Person person;  /* 创建一个Person实例  Person person = {"John Doe", 30, "New York"};*/
        person.name = name;
        person.age  = 30;
        person.city = city;
        
        /* 将Person实例转换为JSON对象 */
        json = ETCDAPI_PersonToJSON(&person);
        
        /* 检查转换是否成功 */
        if (json != NULL)
        {
            jsonString = json_object_to_json_string(json);
            
            /* 检查字符串是否生成成功 */
            if (jsonString != NULL)
            {
                printf("%s\n", jsonString);
                ret = ETCDAPI_SetKey(Key, jsonString);
                if (0 == ret)
                {
                    std::cout << "SET Successful " << std::endl;
                }
            } 
            else 
            {
                fprintf(stderr, "Failed to convert JSON object to string\n");
            }
        
            /* 释放JSON对象内存 */
            json_object_put(json);
        }
    }
    else if (cmd ==DELETE)
    {
        std::cout << "File: " << __FILE__ << ", Line: " << __LINE__ << ", cmd: DELETE" << std::endl;
        char Key[MAX_LEN_OFKEY] = "/test/key/delet";
        int ret = 0xff;
        ret = ETCDAPI_DeleteKey(Key);
        if (0 == ret)
        {
            std::cout << "DELETE Successful " << std::endl;
        }
    }
    else if (cmd == WATCH)
    {
        std::cout << "File: " << __FILE__ << ", Line: " << __LINE__ << ", cmd: WATCH" << std::endl;
        char Key[MAX_LEN_OFKEY] = "/test/key/watch";
        ETCDAPI_WatchKey(Key);
    }
    else 
    {
        std::cout << "Unknown command." << std::endl;
    }

    //std::this_thread::sleep_for(std::chrono::seconds(1));
}


void Client_Print_struPrefixInfo_C()
{
    int i;
    int num = g_struPrefixInfo_C.num;

    std::cout << "--Client_Print_struPrefixInfo_C Start----------------" << std::endl;
    //std::cout << "num = " << num << std::endl;
    for (i = 0;i < num;i++)
    {
        std::cout << "num = " << num << ", i = " << i << ", key = " << g_struPrefixInfo_C.key[i]
                  << ", value = " << g_struPrefixInfo_C.value[i] 
                  << ", Vision : " << g_struPrefixInfo_C.version[i] << std::endl;
    }
    std::cout << "--Client_Print_struPrefixInfo_C End------------------" << std::endl;
}

void Client_Print_struPrefixInfo_C_Back()
{
    int i;
    int num = g_struPrefixInfo_C_Backup.num;

    std::cout << "--print_struPrefixInfo_C_Backup Start----------------" << std::endl;
    //std::cout << "num = " << num << std::endl;
    for (i = 0;i < num;i++)
    {
        std::cout << "num = " << num << ", i = " << i << ", key = " << g_struPrefixInfo_C_Backup.key[i]
                  << ", value = " << g_struPrefixInfo_C_Backup.value[i] 
                  << ", Vision : " << g_struPrefixInfo_C_Backup.version[i] << std::endl;
    }
    std::cout << "--print_struPrefixInfo_C_Backup End------------------" << std::endl;
}

void Client_Print_g_Key_Value_addr()
{
    int i;
    int num = g_struPrefixInfo_C.num;

    std::cout << "--Client_Print_g_Key_Value_addr Start----------------" << std::endl;
    for (i = 0;i < num;i++)
    {
        std::cout << "i = " << i << ", key = " << g_Key_Value_addr[i].cstr_key
                  << ", value = " << g_Key_Value_addr[i].cstr_value << std::endl;
    }
    std::cout << "--Client_Print_g_Key_Value_addr End------------------" << std::endl;
}

/******************************************************************
函数名称: Client_freePrefixInfo_C
功能描述: 释放 PrefixInfo_C 结构体中分配的所有内存
输入参数: struct PrefixInfo_C* Backup_Info
输出参数: 无
返回数值: void
修改历史:
 1. 2024-10-24, 周凯, 新生成函数
*******************************************************************/
void Client_freePrefixInfo_C(struct PrefixInfo_C* Backup_Info)
{
    if (Backup_Info == NULL)
    {
        return;
    }

    /* 释放所有字符串 */
    for (int i = 0; i < Backup_Info->num; i++)
    {
        free(Backup_Info->key[i]);
        free(Backup_Info->value[i]);
    }

    /* 释放指针数组本身（如果它们是动态分配的） */
    //free(info->key);
    //free(info->value);
    /* 注意：这里没有释放 info 结构体本身的内存，因为它可能是静态分配或栈上分配的 */
    /* 如果 info 是动态分配的，你应该在调用这个函数之后释放它 */
}

/******************************************************************
函数名称: Client_deepCopyPrefixInfo_C
功能描述: 该函数深拷贝 PrefixInfo_C 结构体
输入参数: struct PrefixInfo_C* dst
          struct PrefixInfo_C* src
输出参数: 无
返回数值: void
修改历史:
 1. 2024-10-23, 周凯, 新生成函数
*******************************************************************/
void Client_deepCopyPrefixInfo_C(struct PrefixInfo_C* dst, struct PrefixInfo_C* src)
{
    /* 复制基本类型 */
    dst->num = src->num;
    //std::cout << "src num = " << src->num << std::endl;
    //std::cout << "dst num = " << dst->num << std::endl;
    for (int i = 0; i < src->num; i++)
    {
        //dst.created_index[i] = src.created_index[i];
        //dst.modified_index[i] = src.modified_index[i];
        dst->version[i] = src->version[i];
        //dst.ttl[i] = src.ttl[i];

        dst->key[i] = strdup(src->key[i]);
        if (dst->key[i] == NULL)
        {
            std::cout << "Failed to copy string-key" << std::endl;
        }
        dst->value[i] = strdup(src->value[i]);
        if (dst->value[i] == NULL)
        {
            std::cout << "Failed to copy string-value" << std::endl;
        }
        
        #if 0
        // 为每个字符串分配内存并复制内容
        if (src->key[i] != NULL)
        {
            
            dst->key[i] = (char*)malloc(strlen(src->key[i]) + 1);
            strcpy(dst->key[i], src->key[i]);
        }
        else
        {
            dst->key[i] = NULL;
        }
        
        if (src->value[i] != NULL)
        {
            
            dst->value[i] = (char*)malloc(strlen(src->value[i]) + 1);
            strcpy(dst->value[i], src->value[i]);
            std::cout << "dst.value[i] = " << dst->value[i] << std::endl;
        }
        else
        {
            dst->value[i] = NULL;
        }
        #endif
    }
}

/******************************************************************
函数名称: Client_Response_get
功能描述: 读取客户端响应并保存读取键值结果
输入参数: etcd::Response const& resp
输出参数: 无
返回数值: void
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
void Client_Response_get(etcd::Response const& resp)
{
    int num;
    int key_exist = false;
    std::string str_key;
    std::string str_value;
    
    //std::cout << "--------------Client_Response_get----------------" << std::endl;
    if (resp.error_code()) 
    {
        std::cout << "Get " << resp.watch_id() << " fails with "
                  << resp.error_code() << ": " << resp.error_message() << std::endl;
    } 
    else 
    {
        for (unsigned long i = 0; i < resp.keys().size(); ++i)
        {
            //std::cout << "i = " << i;
            //std::cout << ", key = " << resp.value(i).key();
            //std::cout << ", value = " << resp.value(i).as_string() << std::endl;
            //std::cout << "created_index = " << resp.value(i).created_index() << std::endl;
            //std::cout << ", version = " << resp.value(i).version() << std::endl;
            //std::cout << "modified_index = " << resp.value(i).modified_index() << std::endl;
            //std::cout << "ttl = " << resp.value(i).ttl() << std::endl;

            str_key   = resp.value(i).key();
            str_value = resp.value(i).as_string();
            
            memset(g_Key_Value_addr[i].cstr_key, 0, sizeof(g_Key_Value_addr[i].cstr_key)); /* 使用memset将str的内容全部设置为0 */
            memset(g_Key_Value_addr[i].cstr_value, 0, sizeof(g_Key_Value_addr[i].cstr_value)); 
    
            // 使用 std::copy 将 std::string 的内容复制到 char 数组中
            std::copy(str_key.begin(), str_key.end(), g_Key_Value_addr[i].cstr_key);
            std::copy(str_value.begin(), str_value.end(), g_Key_Value_addr[i].cstr_value);
            
            /* 确保字符串以 null 结尾 */
            g_Key_Value_addr[i].cstr_key[str_key.size()] = '\0';
            g_Key_Value_addr[i].cstr_value[str_value.size()] = '\0';
            
            num = g_struPrefixInfo_C.num;
            if (0 == num)  /* 初始添加 */
            {
                g_struPrefixInfo_C.key[0]     = g_Key_Value_addr[i].cstr_key;
                g_struPrefixInfo_C.value[0]   = g_Key_Value_addr[i].cstr_value;
                g_struPrefixInfo_C.version[0] = resp.value(i).version();
                g_struPrefixInfo_C.num++;
            }
            else 
            {
                for (int j = 0;j < num;j++)
                {
                    if (g_struPrefixInfo_C.key[j] == g_Key_Value_addr[i].cstr_key)
                    {
                      g_struPrefixInfo_C.value[j]   = g_Key_Value_addr[i].cstr_value;
                      g_struPrefixInfo_C.version[j] = resp.value(i).version();
                      key_exist = true;
                      std::cout << "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ " << std::endl;  /* 未执行此处 */
                      break;
                    }
                    else
                    {
                        key_exist = false;
                        continue;
                    }
                }
                if (false == key_exist)
                {
                    g_struPrefixInfo_C.key[num]     = g_Key_Value_addr[i].cstr_key;
                    g_struPrefixInfo_C.value[num]   = g_Key_Value_addr[i].cstr_value;
                    g_struPrefixInfo_C.version[num] = resp.value(i).version();
                    g_struPrefixInfo_C.num++;
                }
            }
        }
    }
    
    Client_freePrefixInfo_C(&g_struPrefixInfo_C_Backup);  /* 释放 g_struPrefixInfo_C_Backup 结构体中分配的所有内存 */
    /* 深拷贝注意：在不再需要 g_struPrefixInfo_C_Backup 时，需要释放其指针成员所分配的内存 */
    Client_deepCopyPrefixInfo_C(&g_struPrefixInfo_C_Backup, &g_struPrefixInfo_C);  /* 备份数据 */

    Client_Print_struPrefixInfo_C();
    Client_Print_struPrefixInfo_C_Back();
}

/******************************************************************
函数名称: Client_Response_watch
功能描述: 订阅回调函数
输入参数: etcd::Response const& resp
输出参数: 无
返回数值: void
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
void Client_Response_watch(etcd::Response const& resp)
{
    int num;
    int key_exist = false;
    int delete_location;
    int modify_location;
    std::string str_key;
    std::string str_value;

    std::cout << "--------------Client_Response_watch----------------" << std::endl;
    if (resp.error_code()) 
    {
        std::cout << "Watcher " << resp.watch_id() << " fails with "
                  << resp.error_code() << ": " << resp.error_message() << std::endl;
    }
    else
    {
        //std::cout << "Watcher " << resp.watch_id() << " responses with " << resp.action() << " " << resp.value().as_string() << std::endl;
        //std::cout << "Previous value: " << resp.prev_value().as_string() << std::endl;

        //std::cout << "Events size: " << resp.events().size() << std::endl;
        for (auto const& ev : resp.events()) 
        {
            if (ev.prev_kv().key().find("/leader") == 0 || ev.kv().key().find("/leader") == 0)
            {
                return;
            }
            
            //std::cout << "Value change in events: " << static_cast<int>(ev.event_type()) << std::endl;
            //std::cout << "Watch '" << ev.kv().key() << "'. ModifedRevision : " << ev.kv().modified_index()
            //        << "', Vision : " << ev.kv().version() << ", value = " << ev.kv().as_string() << std::endl;

            str_key   = ev.kv().key();
            str_value = ev.kv().as_string();
        
            num = g_struPrefixInfo_C.num;
            std::cout << "g_struPrefixInfo_C.num =  " << g_struPrefixInfo_C.num << ", CMD = " <<resp.action() << std::endl;
            if ("delete" == resp.action())
            {
                for (int j = 0;j < num;j++)
                {
                    if (g_struPrefixInfo_C.key[j] == ev.kv().key())
                    {
                        delete_location = j;
                        break;
                    }
                }
                for (int p = delete_location;p < (num - 1);p++)
                {
                    g_struPrefixInfo_C.key[p]     = g_struPrefixInfo_C.key[p + 1];
                    g_struPrefixInfo_C.value[p]   = g_struPrefixInfo_C.value[p + 1];
                    g_struPrefixInfo_C.version[p] = g_struPrefixInfo_C.version[p + 1]; 
                }
                g_struPrefixInfo_C.num--;
            }
            else 
            {
                if (0 == num)  /* 初始添加 */
                {
                    memset(g_Key_Value_addr[0].cstr_key, 0, sizeof(g_Key_Value_addr[0].cstr_key)); /* 使用memset将str的内容全部设置为0 */
                    memset(g_Key_Value_addr[0].cstr_value, 0, sizeof(g_Key_Value_addr[0].cstr_value));
            
                    /* 使用 std::copy 将 std::string 的内容复制到 char 数组中 */ 
                    std::copy(str_key.begin(), str_key.end(), g_Key_Value_addr[0].cstr_key);
                    std::copy(str_value.begin(), str_value.end(), g_Key_Value_addr[0].cstr_value);
                            
                    g_Key_Value_addr[0].cstr_key[str_key.size()] = '\0';/* 确保字符串以 null 结尾 */
                    g_Key_Value_addr[0].cstr_value[str_value.size()] = '\0';
                
                    std::cout << ", key = " << ev.kv().key();
                    std::cout << ", value = " << ev.kv().as_string() << std::endl;
                    
                    g_struPrefixInfo_C.key[0]     = g_Key_Value_addr[0].cstr_key;
                    g_struPrefixInfo_C.value[0]   = g_Key_Value_addr[0].cstr_value;
                    g_struPrefixInfo_C.version[0] = ev.kv().version(); 
                    g_struPrefixInfo_C.num++;
                }
                else 
                {
                    for (int j = 0;j < num;j++)
                    {
                        if (g_struPrefixInfo_C.key[j] == ev.kv().key())   /* 对键值进行修改 */
                        {
                            modify_location = j;
                            std::cout << "modify_location = " << modify_location << std::endl; 
                            key_exist = true;
                            break;
                        }
                        else
                        {
                            key_exist = false;
                            continue;
                        }
                    }
                    
                    if (true == key_exist)    /* 修改已存在键的值 */
                    {
                        memset(g_Key_Value_addr[modify_location].cstr_value, 0, sizeof(g_Key_Value_addr[modify_location].cstr_value)); /* 使用memset将str的内容全部设置为0 */
                        std::copy(str_value.begin(), str_value.end(), g_Key_Value_addr[modify_location].cstr_value); /* 使用 std::copy 将 std::string 的内容复制到 char 数组中 */
                        g_Key_Value_addr[modify_location].cstr_value[str_value.size()] = '\0'; /* 确保字符串以 null 结尾 */
                        
                        g_struPrefixInfo_C.value[modify_location]   = g_Key_Value_addr[modify_location].cstr_value;
                        g_struPrefixInfo_C.version[modify_location] = ev.kv().version();
                    
                    }
                    else if (false == key_exist)    /* 增加键值 */
                    {
                        memset(g_Key_Value_addr[num].cstr_key, 0, sizeof(g_Key_Value_addr[num].cstr_key));  /* 使用memset将str的内容全部设置为0 */
                        memset(g_Key_Value_addr[num].cstr_value, 0, sizeof(g_Key_Value_addr[num].cstr_value));

                        /* 使用 std::copy 将 std::string 的内容复制到 char 数组中 */
                        std::copy(str_key.begin(), str_key.end(), g_Key_Value_addr[num].cstr_key);
                        std::copy(str_value.begin(), str_value.end(), g_Key_Value_addr[num].cstr_value);
                        
                        g_Key_Value_addr[num].cstr_key[str_key.size()] = '\0';/* 确保字符串以 null 结尾 */
                        g_Key_Value_addr[num].cstr_value[str_value.size()] = '\0';
                        
                        g_struPrefixInfo_C.key[num]     = g_Key_Value_addr[num].cstr_key;
                        g_struPrefixInfo_C.value[num]   = g_Key_Value_addr[num].cstr_value;
                        g_struPrefixInfo_C.version[num] = ev.kv().version();
                        g_struPrefixInfo_C.num++;
                    }
                }
            }
        }
        
        Client_freePrefixInfo_C(&g_struPrefixInfo_C_Backup);/* 释放 g_struPrefixInfo_C_Backup 结构体中分配的所有内存 */
        /* 深拷贝注意：在不再需要 g_struPrefixInfo_C_Backup 时，需要释放其指针成员所分配的内存 */
        Client_deepCopyPrefixInfo_C(&g_struPrefixInfo_C_Backup, &g_struPrefixInfo_C);/* 备份数据 */
        Client_Print_struPrefixInfo_C();
        Client_Print_struPrefixInfo_C_Back();
        //Client_Print_g_Key_Value_addr();
    }
}

/******************************************************************
函数名称: threadFunction_get
功能描述: 读取客户端进程函数
输入参数: 无
输出参数: 无
返回数值: void
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
int Client_threadFunction_get()
{
    /* etcd::Client etcd("http://192.168.2.75:2389"); */
    etcd::Client etcd(etcd_url);  /* 与上一行作用相同 */
    
    /* 输出相同前缀的键的值 */
    /* std::cout << "**************** get **************** " << std::endl;*/
    etcd::Response resp = etcd.ls("/").get();
    Client_Response_get(resp);
    return 0;
}

/******************************************************************
函数名称: threadFunction_watch
功能描述: 订阅客户端进程函数
输入参数: 无
输出参数: 无
返回数值: void
修改历史:
 1. 2024-10-22, 周凯, 新生成函数
*******************************************************************/
int Client_threadFunction_watch()
{
    #if 0  /* 监听单个键 */
    std::string my_prefix_watch = "/";
    etcd::SyncClient client(etcd_url);
    
    auto current_index = client.head().index();
    std::cout << "Current index " << current_index << std::endl;
    
    auto wait_cb = [&](bool) {};
    std::cout << "--1--watch--输出某键值" << std::endl;
    etcd::Watcher w(client, my_prefix_watch, current_index, std::move(Client_Response_watch), std::move(wait_cb), false);
    #endif
    
    while (1)
    {
        std::string str_key = "/";
        //auto wait_cb = [&](bool) {};
        //etcd::Watcher watcher(etcd_url, str_key, Client_Response_watch, wait_cb, true);
        etcd::Watcher watcher(etcd_url, str_key, Client_Response_watch, true);
        getchar();
    }

    /* getchar(); */
    /* watcher.Cancel(); */
    /* std::this_thread::sleep_for(std::chrono::seconds(60)); */
    return 0;
}

int main()
{
    /* 创建std::thread对象，分别传入不同的函数作为线程的执行任务 */ 
    std::thread t_ClientGet(Client_threadFunction_get);
    t_ClientGet.join(); /* 等待两个线程都执行完毕 */

    //std::thread t_get(ETCDAPI_threadFunction_all, GET);
    //t_get.join();
   
    //std::thread t_set(ETCDAPI_threadFunction_all, SET);
    //t_set.join();
    
    std::thread t_delete(ETCDAPI_threadFunction_all, DELETE);
    t_delete.join();
    
    //std::thread t_watch(ETCDAPI_threadFunction_all, WATCH); /* 暂不支持 */
    
    
    std::thread t_ClientWatch(Client_threadFunction_watch);
    
    //t_watch.join(); /* 暂不支持 */
    t_ClientWatch.join();
    
    return 0;
}





/****************************************************************************
目前不再需要的内容
*****************************************************************************/
#if 0
void watcher_cb(etcd::Response const & resp)
{
    if (resp.error_code())
    {
        //error
        std::cout<<"watcher_cb error_code:"<<resp.error_code()<<" and error";
        std::cout <<" msg:"<<resp.error_message()<<std::endl;
    }
    else
    {
        //success
        if(resp.action() == "set")
        {
            std::cout<<"set key:"<<resp.key(resp.index())<<" value:"<<resp.value(resp.index()).as_string();
        }
        else if(resp.action() == "delete")
        {
            std::cout<<"set key:"<<resp.key(resp.index())<<" value:"<<resp.value(resp.index()).as_string();
        }
    }

}

void CppToC_struPrefixInfo()
{
    int i;
    int num = g_struPrefixInfo.num;	
    std::string str_key;
    std::string str_value;
        
    g_struPrefixInfo_C.num = num;
    
    //std::cout << "--CppToC_struPrefixInfo Start----------------" << std::endl;
    for (i = 0;i < num;i++)
    {
        str_key   = g_struPrefixInfo.key[i];
        str_value = g_struPrefixInfo.as_string[i];
        
        
        memset(g_Key_Value_addr[i].cstr_key, 0, sizeof(g_Key_Value_addr[i].cstr_key)); // 使用memset将str的内容全部设置为0
        memset(g_Key_Value_addr[i].cstr_value, 0, sizeof(g_Key_Value_addr[i].cstr_value));
            
        // 使用 std::copy 将 std::string 的内容复制到 char 数组中
        std::copy(str_key.begin(), str_key.end(), g_Key_Value_addr[i].cstr_key);
        std::copy(str_value.begin(), str_value.end(), g_Key_Value_addr[i].cstr_value);
        // 确保字符串以 null 结尾
        g_Key_Value_addr[i].cstr_key[str_key.size()] = '\0';
        g_Key_Value_addr[i].cstr_value[str_value.size()] = '\0';
        
        // 打印复制的 C 字符串
        //std::cout << "Copied C string: " << g_Key_Value_addr[i].cstr_key << std::endl;

        g_struPrefixInfo_C.key[i]     = g_Key_Value_addr[i].cstr_key;
        g_struPrefixInfo_C.value[i]   = g_Key_Value_addr[i].cstr_value;
        g_struPrefixInfo_C.version[i] = g_struPrefixInfo.version[i];
      
    }
    //std::cout << "--CppToC_struPrefixInfo End------------------" << std::endl;
}
#endif